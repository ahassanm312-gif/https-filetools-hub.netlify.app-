import React, { useState } from "react";
import { Link, Outlet } from "react-router-dom";
import { Menu, X, FileBox, Search, Moon } from "lucide-react";
import { Button } from "../components/ui/Button";

export function MainLayout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "PDF Tools", path: "/tools?category=pdf" },
    { name: "Image Tools", path: "/tools?category=image" },
    { name: "Text Tools", path: "/tools?category=text" },
    { name: "All Tools", path: "/tools" },
    { name: "Blog", path: "/blog" },
    { name: "About", path: "/about" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-indigo-600 p-1.5 rounded-lg">
              <FileBox className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900">FileTools Hub</span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link key={link.name} to={link.path} className="text-sm font-medium text-slate-600 hover:text-indigo-600 transition-colors">
                {link.name}
              </Link>
            ))}
          </nav>
          
          <div className="hidden md:flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <Moon className="w-5 h-5" />
            </Button>
          </div>
          
          <button 
            className="md:hidden p-2 text-slate-600"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 absolute w-full z-40 top-16 shadow-lg">
          <div className="px-4 pt-2 pb-6 space-y-1">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                to={link.path} 
                className="block px-3 py-3 rounded-md text-base font-medium text-slate-700 hover:text-indigo-600 hover:bg-slate-50"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Tools</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link to="/tools?category=pdf" className="hover:text-indigo-600">PDF Tools</Link></li>
                <li><Link to="/tools?category=image" className="hover:text-indigo-600">Image Tools</Link></li>
                <li><Link to="/tools?category=text" className="hover:text-indigo-600">Text Tools</Link></li>
                <li><Link to="/tools" className="hover:text-indigo-600">All Tools</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link to="/about" className="hover:text-indigo-600">About</Link></li>
                <li><Link to="/contact" className="hover:text-indigo-600">Contact</Link></li>
                <li><Link to="/blog" className="hover:text-indigo-600">Blog</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li><Link to="/privacy-policy" className="hover:text-indigo-600">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-indigo-600">Terms of Service</Link></li>
                <li><Link to="/cookie-policy" className="hover:text-indigo-600">Cookie Policy</Link></li>
                <li><Link to="/disclaimer" className="hover:text-indigo-600">Disclaimer</Link></li>
              </ul>
            </div>
            <div>
              <Link to="/" className="flex items-center gap-2 mb-4">
                <div className="bg-indigo-600 p-1.5 rounded-lg inline-flex">
                  <FileBox className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-bold tracking-tight text-slate-900">FileTools Hub</span>
              </Link>
              <p className="text-sm text-slate-500 mb-4">
                Convert, compress, edit and manage PDFs, images and documents online — quickly and easily.
              </p>
            </div>
          </div>
          <div className="border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-500">
              © {new Date().getFullYear()} FileTools Hub. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
