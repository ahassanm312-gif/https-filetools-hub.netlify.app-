let sharedFiles: File[] = [];

export const setSharedFiles = (files: File[]) => {
  sharedFiles = files;
};

export const getSharedFiles = () => {
  const files = [...sharedFiles];
  sharedFiles = [];
  return files;
};
