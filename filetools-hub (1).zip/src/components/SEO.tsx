import React from "react";
import { Helmet } from "react-helmet-async";
import { useLocation } from "react-router-dom";
import { getCanonicalUrl } from "../utils/site";

interface SEOProps {
  title: string;
  description: string;
  canonicalUrl?: string;
  type?: "website" | "article";
  structuredData?: Record<string, any> | Array<Record<string, any>>;
}

export function SEO({ title, description, canonicalUrl, type = "website", structuredData }: SEOProps) {
  const location = useLocation();
  const siteName = "FileTools Hub";
  const fullTitle = `${title} | ${siteName}`;
  const finalCanonical = canonicalUrl || getCanonicalUrl(location.pathname);

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={finalCanonical} />
      
      {/* Open Graph */}
      <meta property="og:site_name" content={siteName} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:type" content={type} />
      <meta property="og:url" content={finalCanonical} />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />

      {/* Optional Structured Data */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
}

