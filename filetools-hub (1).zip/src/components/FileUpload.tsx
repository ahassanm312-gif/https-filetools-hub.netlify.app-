import React, { useRef, useState } from "react";
import { UploadCloud, X, File as FileIcon } from "lucide-react";
import { cn } from "../lib/utils";
import { Button } from "./ui/Button";

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  multiple?: boolean;
  accept?: string;
  maxFiles?: number;
  maxSizeMB?: number;
}

export function FileUpload({
  onFilesSelected,
  multiple = false,
  accept,
  maxFiles = 20,
  maxSizeMB = 100,
}: FileUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFiles = (files: FileList | File[]) => {
    setError(null);
    const fileArray = Array.from(files);
    
    if (fileArray.length === 0) return;
    
    if (!multiple && fileArray.length > 1) {
      setError("Please select only one file.");
      return;
    }

    if (fileArray.length > maxFiles) {
      setError(`Maximum ${maxFiles} files allowed.`);
      return;
    }

    const invalidSize = fileArray.find(f => f.size > maxSizeMB * 1024 * 1024);
    if (invalidSize) {
      setError(`Files must be less than ${maxSizeMB}MB.`);
      return;
    }

    onFilesSelected(fileArray);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  return (
    <div className="w-full">
      <div
        className={cn(
          "relative border-2 border-dashed rounded-xl p-10 text-center transition-colors flex flex-col items-center justify-center cursor-pointer min-h-[300px]",
          dragActive ? "border-indigo-500 bg-indigo-50/50" : "border-slate-300 hover:border-indigo-400 bg-slate-50 hover:bg-slate-100"
        )}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
      >
        <input
          ref={inputRef}
          type="file"
          multiple={multiple}
          accept={accept}
          onChange={handleChange}
          className="hidden"
        />
        
        <div className="bg-white p-4 rounded-full shadow-sm mb-4">
          <UploadCloud className="w-8 h-8 text-indigo-600" />
        </div>
        
        <h3 className="text-xl font-semibold mb-2">Drag & Drop your files here</h3>
        <p className="text-slate-500 mb-6 max-w-sm">
          or click to browse your files. {multiple ? `Up to ${maxFiles} files.` : "Select one file."} 
          Max size: {maxSizeMB}MB.
        </p>
        
        <Button size="lg" className="pointer-events-none">
          Select Files
        </Button>
      </div>
      
      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-md text-sm font-medium">
          {error}
        </div>
      )}
    </div>
  );
}
