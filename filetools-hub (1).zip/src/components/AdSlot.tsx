import React from "react";

interface AdSlotProps {
  type: "top" | "header" | "middle" | "bottom" | "sidebar";
  className?: string;
}

export function AdSlot({ type, className = "" }: AdSlotProps) {
  // In a real app, this would integrate Google AdSense or Adsterra scripts
  // based on the environment variables.
  
  return (
    <div className={`w-full bg-slate-100 border border-slate-200 rounded flex items-center justify-center text-slate-400 text-sm overflow-hidden ${className}`} style={{ minHeight: '90px' }}>
      <div className="text-center p-4">
        <p className="font-medium">Advertisement</p>
        <p className="text-xs opacity-75">Space reserved for {type} ad</p>
      </div>
    </div>
  );
}
