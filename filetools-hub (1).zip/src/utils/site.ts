/// <reference types="vite/client" />

export const DEFAULT_SITE_URL = "https://filetoolshub.com";

/**
 * Returns the configured site URL from VITE_SITE_URL, falling back to window.location.origin or DEFAULT_SITE_URL.
 */
export function getSiteUrl(): string {
  const envUrl = import.meta.env.VITE_SITE_URL;
  if (envUrl && typeof envUrl === "string" && envUrl.trim().length > 0) {
    return envUrl.trim().replace(/\/+$/, "");
  }
  if (typeof window !== "undefined" && window.location && window.location.origin) {
    return window.location.origin.replace(/\/+$/, "");
  }
  return DEFAULT_SITE_URL;
}

/**
 * Generates an absolute canonical URL for the given pathname.
 */
export function getCanonicalUrl(pathname: string = "/"): string {
  const siteUrl = getSiteUrl();
  const cleanPath = pathname.startsWith("/") ? pathname : `/${pathname}`;
  // Ensure homepage canonical is either domain or domain/
  return `${siteUrl}${cleanPath === "/" ? "/" : cleanPath}`;
}
