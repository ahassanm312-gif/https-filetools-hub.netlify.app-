/// <reference types="vite/client" />

export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || "").replace(/\/+$/, "");

export const getApiUrl = (path: string): string => {
  const cleanPath = path.startsWith("/") ? path : `/${path}`;
  if (!API_BASE_URL) {
    return cleanPath;
  }
  return `${API_BASE_URL}${cleanPath}`;
};

/**
 * Safely executes a fetch request to the API with comprehensive error handling
 * that prevents "Unexpected token <" or opaque "Failed to fetch" errors.
 */
export async function apiFetch<T = any>(path: string, options?: RequestInit): Promise<T> {
  const url = getApiUrl(path);
  let response: Response;

  try {
    response = await fetch(url, options);
  } catch (err: any) {
    const errorMsg = err?.message || "Failed to fetch";
    console.error(`Network fetch failed for ${url}:`, err);
    throw new Error(
      `Unable to connect to the backend server (${errorMsg}). Please verify that the API server is running and accessible at ${url}.`
    );
  }

  const contentType = response.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");

  if (!response.ok) {
    if (isJson) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || errorData.message || `Request failed with status ${response.status}`);
    } else {
      const text = await response.text().catch(() => "");
      if (text.includes("<!doctype html>") || text.includes("<html")) {
        throw new Error(
          `Server returned an HTML error page (status ${response.status}) instead of JSON from ${url}. If using a separate frontend host (e.g. Netlify), verify that VITE_API_BASE_URL is set to your backend server URL.`
        );
      }
      throw new Error(text.trim() || `Request failed with status ${response.status}`);
    }
  }

  if (!isJson) {
    const text = await response.text().catch(() => "");
    if (text.includes("<!doctype html>") || text.includes("<html")) {
      throw new Error(
        `Received HTML instead of JSON from ${url}. If this app is hosted statically (e.g. on Netlify), the API request was routed to index.html because VITE_API_BASE_URL is not set to your active backend server URL.`
      );
    }
    try {
      return JSON.parse(text);
    } catch {
      throw new Error(`Unexpected non-JSON response received from ${url}`);
    }
  }

  return await response.json();
}
