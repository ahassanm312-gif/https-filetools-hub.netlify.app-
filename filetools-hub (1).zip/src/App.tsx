import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";

import { MainLayout } from "./layouts/MainLayout";
import { HomePage } from "./pages/HomePage";
import { AllToolsPage } from "./pages/AllToolsPage";
import { ImageCompressorPage } from "./pages/ImageCompressorPage";
import { ImageConverterPage } from "./pages/ImageConverterPage";
import { ImageResizerPage } from "./pages/ImageResizerPage";
import { ImageToPdfPage } from "./pages/ImageToPdfPage";
import { SplitPdfPage } from "./pages/SplitPdfPage";
import { MergePdfPage } from "./pages/MergePdfPage";
import { WordCounterPage } from "./pages/WordCounterPage";
import { CaseConverterPage } from "./pages/CaseConverterPage";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { LegalPages } from "./pages/LegalPages";
import { PdfToJpgPage } from "./pages/PdfToJpgPage";
import { CompressPdfPage } from "./pages/CompressPdfPage";
import { TextToPdfPage } from "./pages/TextToPdfPage";
import { BlogPage } from "./pages/BlogPage";
import { BlogPostPage } from "./pages/BlogPostPage";

export default function App() {
  return (
    <HelmetProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainLayout />}>
            <Route index element={<HomePage />} />
            <Route path="tools" element={<AllToolsPage />} />
            <Route path="image-compressor" element={<ImageCompressorPage />} />
            <Route path="image-converter" element={<ImageConverterPage />} />
            <Route path="image-resizer" element={<ImageResizerPage />} />
            <Route path="jpg-to-pdf" element={<ImageToPdfPage />} />
            <Route path="pdf-to-jpg" element={<PdfToJpgPage />} />
            <Route path="split-pdf" element={<SplitPdfPage />} />
            <Route path="merge-pdf" element={<MergePdfPage />} />
            <Route path="compress-pdf" element={<CompressPdfPage />} />
            <Route path="text-to-pdf" element={<TextToPdfPage />} />
            <Route path="blog" element={<BlogPage />} />
            <Route path="blog/:slug" element={<BlogPostPage />} />
            <Route path="word-counter" element={<WordCounterPage />} />
            <Route path="case-converter" element={<CaseConverterPage />} />
            
            <Route path="about" element={<AboutPage />} />
            <Route path="contact" element={<ContactPage />} />
            <Route path="privacy-policy" element={<LegalPages type="privacy" />} />
            <Route path="terms" element={<LegalPages type="terms" />} />
            <Route path="cookie-policy" element={<LegalPages type="cookie" />} />
            <Route path="disclaimer" element={<LegalPages type="disclaimer" />} />
            
            {/* Fallback for undefined routes */}
            <Route path="*" element={
              <div className="text-center py-24">
                <h2 className="text-2xl font-bold">404 - Page Not Found</h2>
                <p className="mt-2 text-slate-600">The page or tool you are looking for doesn't exist.</p>
              </div>
            } />
          </Route>
        </Routes>
      </BrowserRouter>
    </HelmetProvider>
  );
}
