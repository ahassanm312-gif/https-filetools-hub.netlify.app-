import { getApiUrl, apiFetch } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { FileUpload } from "../components/FileUpload";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, AlertCircle } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function CompressPdfPage() {
  const [file, setFile] = useState<File | null>(null);
  const [level, setLevel] = useState("medium");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ downloadUrl: string; filename: string; originalSize: number; newSize: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (files: File[]) => {
    setFile(files[0]);
    setResult(null);
    setError(null);
  };

  const handleCompress = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    formData.append("level", level);

    try {
      const data = await apiFetch<{ downloadUrl: string; filename: string; originalSize: number; newSize: number }>("/api/pdf/compress", {
        method: "POST",
        body: formData,
      });
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getReductionPercentage = () => {
    if (!result) return 0;
    if (result.newSize >= result.originalSize) return 0;
    return Math.round(((result.originalSize - result.newSize) / result.originalSize) * 100);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Compress PDF" 
        description="Reduce PDF file size online while maintaining quality." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Compress PDF</h1>
        <p className="text-slate-600">Reduce your PDF file size genuinely without losing readability.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!file && !result && (
        <FileUpload 
          onFilesSelected={handleFileSelect} 
          accept="application/pdf" 
          maxSizeMB={100}
        />
      )}

      {file && !result && (
        <Card className="p-6">
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <p className="font-medium text-slate-900 truncate max-w-[200px] sm:max-w-md">{file.name}</p>
                <p className="text-sm text-slate-500">{formatBytes(file.size)}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setFile(null)}>Remove</Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-3">Compression Level</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setLevel("low")}
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    level === "low" ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="font-medium text-slate-900">Low Compression</div>
                  <div className="text-xs text-slate-500 mt-1">High quality, less size reduction</div>
                </button>
                <button
                  type="button"
                  onClick={() => setLevel("medium")}
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    level === "medium" ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="font-medium text-slate-900">Medium Compression</div>
                  <div className="text-xs text-slate-500 mt-1">Good quality, good compression</div>
                </button>
                <button
                  type="button"
                  onClick={() => setLevel("high")}
                  className={`p-4 border rounded-lg text-left transition-colors ${
                    level === "high" ? "border-indigo-600 bg-indigo-50" : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="font-medium text-slate-900">High Compression</div>
                  <div className="text-xs text-slate-500 mt-1">Lower quality, maximum size reduction</div>
                </button>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm font-medium flex items-start gap-2.5 text-left">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <div className="flex-1">{error}</div>
              </div>
            )}

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleCompress}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Compressing...</>
              ) : (
                "Compress PDF"
              )}
            </Button>
          </div>
        </Card>
      )}

      {result && (
        <Card className="text-center p-10">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Download className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold mb-2">PDF Compressed!</h3>
          
          <div className="bg-slate-50 p-4 rounded-lg inline-block mx-auto mb-8 min-w-[280px]">
            <div className="flex justify-between items-center text-sm mb-2">
              <span className="text-slate-500">Original Size:</span>
              <span className="font-medium">{formatBytes(result.originalSize)}</span>
            </div>
            <div className="flex justify-between items-center text-sm mb-2">
              <span className="text-slate-500">New Size:</span>
              <span className="font-bold text-green-600">{formatBytes(result.newSize)}</span>
            </div>
            <div className="pt-2 mt-2 border-t border-slate-200 flex justify-between items-center">
              <span className="text-slate-500">Saved:</span>
              <span className="font-bold text-indigo-600">{getReductionPercentage()}%</span>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                Download Compressed PDF
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={() => { setFile(null); setResult(null); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Compress Another PDF
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
