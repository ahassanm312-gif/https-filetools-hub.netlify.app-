import { getApiUrl, apiFetch } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { FileUpload } from "../components/FileUpload";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, GripVertical, Trash2, AlertCircle } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function MergePdfPage() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ downloadUrl: string; filename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (newFiles: File[]) => {
    setFiles((prev) => [...prev, ...newFiles]);
    setResult(null);
    setError(null);
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleMerge = async () => {
    if (files.length < 2) {
      setError("Please select at least 2 PDF files to merge.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    files.forEach(file => {
      formData.append("files", file);
    });

    try {
      const data = await apiFetch<{ downloadUrl: string; filename: string }>("/api/pdf/merge", {
        method: "POST",
        body: formData,
      });
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Merge PDF" 
        description="Combine multiple PDFs into one single file easily and securely." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Merge PDF</h1>
        <p className="text-slate-600">Combine multiple PDF files into one document.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!result && (
        <>
          <div className="mb-6">
            <FileUpload 
              onFilesSelected={handleFileSelect} 
              accept="application/pdf" 
              multiple 
              maxFiles={20}
            />
          </div>

          {files.length > 0 && (
            <Card className="p-6">
              <div className="flex flex-col gap-4">
                <h3 className="font-medium text-slate-900">Selected Files ({files.length})</h3>
                <ul className="divide-y divide-slate-100">
                  {files.map((file, i) => (
                    <li key={i} className="py-3 flex items-center justify-between group">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <GripVertical className="w-4 h-4 text-slate-300 cursor-move" />
                        <span className="truncate max-w-[200px] sm:max-w-md text-sm font-medium text-slate-700">{file.name}</span>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeFile(i)} className="text-red-500 hover:text-red-700 hover:bg-red-50">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </li>
                  ))}
                </ul>

                {error && (
                  <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm font-medium flex items-start gap-2.5 text-left">
                    <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                    <div className="flex-1">{error}</div>
                  </div>
                )}

                <Button 
                  size="lg" 
                  className="w-full mt-4" 
                  onClick={handleMerge}
                  disabled={isProcessing || files.length < 2}
                >
                  {isProcessing ? (
                    <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Merging...</>
                  ) : (
                    "Merge PDFs"
                  )}
                </Button>
                {files.length < 2 && (
                  <p className="text-xs text-center text-slate-500">Please add at least 2 files to merge.</p>
                )}
              </div>
            </Card>
          )}
        </>
      )}

      {result && (
        <Card className="text-center p-10">
          <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Download className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-2xl font-bold mb-6">PDFs Merged Successfully!</h3>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                Download Merged PDF
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={() => { setFiles([]); setResult(null); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Merge More Files
            </Button>
          </div>
        </Card>
      )}

      <div className="prose prose-slate max-w-none mt-16">
        <h2>How to Merge PDF Files?</h2>
        <ol>
          <li>Drag and drop multiple PDF files into the upload box.</li>
          <li>Review your selected files in the list.</li>
          <li>Click on "Merge PDFs" to combine them.</li>
          <li>Download your single merged PDF file.</li>
        </ol>
      </div>
    </div>
  );
}
