import { getApiUrl, apiFetch } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { FileUpload } from "../components/FileUpload";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, FileArchive, ImageIcon, AlertCircle } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function PdfToJpgPage() {
  const [file, setFile] = useState<File | null>(null);
  const [startPage, setStartPage] = useState("1");
  const [endPage, setEndPage] = useState("");
  const [resolution, setResolution] = useState("150");
  const [quality, setQuality] = useState("80");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ images: {filename: string, downloadUrl: string}[]; zipUrl: string; zipFilename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (files: File[]) => {
    setFile(files[0]);
    setResult(null);
    setError(null);
  };

  const handleConvert = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    if (startPage) formData.append("startPage", startPage);
    if (endPage) formData.append("endPage", endPage);
    formData.append("resolution", resolution);
    formData.append("quality", quality);

    try {
      const data = await apiFetch<{
        success: boolean;
        images: { filename: string; downloadUrl: string }[];
        zipUrl: string;
        zipFilename: string;
      }>("/api/pdf/to-jpg", {
        method: "POST",
        body: formData,
      });

      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="PDF to JPG" 
        description="Extract and convert PDF pages into high quality JPG images." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">PDF to JPG Converter</h1>
        <p className="text-slate-600">Convert your PDF pages to real high-quality JPG images.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!file && !result && (
        <FileUpload 
          onFilesSelected={handleFileSelect} 
          accept="application/pdf" 
          maxSizeMB={50}
        />
      )}

      {file && !result && (
        <Card className="p-6">
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <p className="font-medium text-slate-900 truncate max-w-[200px] sm:max-w-md">{file.name}</p>
                <p className="text-sm text-slate-500">{formatBytes(file.size)}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setFile(null)}>Remove</Button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Start Page</label>
                <input 
                  type="number" 
                  min="1"
                  value={startPage}
                  onChange={(e) => setStartPage(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">End Page (Optional)</label>
                <input 
                  type="number" 
                  min="1"
                  value={endPage}
                  onChange={(e) => setEndPage(e.target.value)}
                  placeholder="e.g. 5"
                  className="w-full p-2 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Resolution (DPI)</label>
                <select 
                  value={resolution}
                  onChange={(e) => setResolution(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                >
                  <option value="72">72 DPI (Web)</option>
                  <option value="150">150 DPI (Good)</option>
                  <option value="300">300 DPI (High Quality/Print)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">JPG Quality</label>
                <input 
                  type="range" 
                  min="10" 
                  max="100" 
                  value={quality}
                  onChange={(e) => setQuality(e.target.value)}
                  className="w-full mt-2"
                />
                <div className="text-right text-xs text-slate-500 mt-1">{quality}%</div>
              </div>
            </div>

            {error && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">Conversion Error</p>
                  <p className="mt-0.5 text-red-600">{error}</p>
                </div>
              </div>
            )}

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleConvert}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Converting Pages...</>
              ) : (
                "Convert PDF to JPG"
              )}
            </Button>
          </div>
        </Card>
      )}

      {result && (
        <div className="space-y-6">
          <Card className="text-center p-10">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ImageIcon className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold mb-6">PDF Converted Successfully!</h3>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" asChild>
                <a href={getApiUrl(result.zipUrl)} download={result.zipFilename}>
                  <FileArchive className="w-4 h-4 mr-2" /> Download All (ZIP)
                </a>
              </Button>
              <Button variant="outline" size="lg" onClick={() => { setFile(null); setResult(null); }}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Convert Another PDF
              </Button>
            </div>
          </Card>

          {result.images.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {result.images.map((img, i) => (
                <Card key={i} className="p-3 flex flex-col items-center justify-between">
                  <div className="w-full aspect-[3/4] bg-slate-100 rounded flex items-center justify-center mb-3 overflow-hidden">
                    <img 
                      src={getApiUrl(img.downloadUrl)} 
                      alt={`Page ${i+1}`} 
                      className="w-full h-full object-cover" 
                      loading="lazy" 
                    />
                  </div>
                  <Button variant="secondary" size="sm" className="w-full text-xs" asChild>
                    <a href={getApiUrl(img.downloadUrl)} download={img.filename}>
                      <Download className="w-3 h-3 mr-1" /> Page {i + (parseInt(startPage) || 1)}
                    </a>
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
