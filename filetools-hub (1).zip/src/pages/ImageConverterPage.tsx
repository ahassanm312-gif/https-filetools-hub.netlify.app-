import { apiFetch, getApiUrl } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { FileUpload } from "../components/FileUpload";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, AlertCircle } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function ImageConverterPage() {
  const [file, setFile] = useState<File | null>(null);
  const [format, setFormat] = useState("png");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ downloadUrl: string; filename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (files: File[]) => {
    setFile(files[0]);
    setResult(null);
    setError(null);
  };

  const handleConvert = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    formData.append("format", format);

    try {
      const data = await apiFetch<{ downloadUrl: string; filename: string }>(
        "/api/image/convert",
        {
          method: "POST",
          body: formData,
        }
      );
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Image Converter" 
        description="Convert JPG to PNG, WEBP and more. Free online image format converter." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Image Converter</h1>
        <p className="text-slate-600">Convert your image to different formats instantly.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!file && !result && (
        <FileUpload 
          onFilesSelected={handleFileSelect} 
          accept="image/*" 
          maxSizeMB={20}
        />
      )}

      {file && !result && (
        <Card className="p-6">
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <p className="font-medium text-slate-900 truncate max-w-[200px] sm:max-w-md">{file.name}</p>
                <p className="text-sm text-slate-500">{formatBytes(file.size)}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setFile(null)}>Remove</Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Convert to format:
              </label>
              <select 
                value={format}
                onChange={(e) => setFormat(e.target.value)}
                className="w-full sm:w-1/2 p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
              >
                <option value="jpeg">JPG / JPEG</option>
                <option value="png">PNG</option>
                <option value="webp">WEBP</option>
              </select>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm font-medium">
                {error}
              </div>
            )}

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleConvert}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Converting...</>
              ) : (
                `Convert to ${format.toUpperCase()}`
              )}
            </Button>
          </div>
        </Card>
      )}

      {result && (
        <Card className="text-center p-10">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Download className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold mb-6">Image Converted Successfully!</h3>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                Download File
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={() => { setFile(null); setResult(null); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Convert Another
            </Button>
          </div>
        </Card>
      )}

      <div className="prose prose-slate max-w-none mt-16">
        <h2>How to Convert an Image?</h2>
        <ol>
          <li>Upload your source image.</li>
          <li>Select the desired output format (JPG, PNG, WEBP).</li>
          <li>Click the Convert button.</li>
          <li>Download your newly formatted image.</li>
        </ol>
      </div>
    </div>
  );
}
