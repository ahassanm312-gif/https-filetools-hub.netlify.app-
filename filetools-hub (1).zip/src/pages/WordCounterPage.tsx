import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Copy, Trash } from "lucide-react";

export function WordCounterPage() {
  const [text, setText] = useState("");

  const wordCount = text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
  const charCount = text.length;
  const charCountNoSpace = text.replace(/\s/g, "").length;
  const lineCount = text === "" ? 0 : text.split(/\r\n|\r|\n/).length;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Word Counter" 
        description="Free online word counter and character counter tool. Check word density and text statistics instantly." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Word & Character Counter</h1>
        <p className="text-slate-600">Count words, characters, and lines instantly in your browser.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
        <Card className="p-4 bg-indigo-50 border-indigo-100">
          <p className="text-sm text-indigo-600 font-medium mb-1">Words</p>
          <p className="text-3xl font-bold text-slate-900">{wordCount}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-slate-500 font-medium mb-1">Characters</p>
          <p className="text-3xl font-bold text-slate-900">{charCount}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-slate-500 font-medium mb-1">Characters (no space)</p>
          <p className="text-3xl font-bold text-slate-900">{charCountNoSpace}</p>
        </Card>
        <Card className="p-4">
          <p className="text-sm text-slate-500 font-medium mb-1">Lines</p>
          <p className="text-3xl font-bold text-slate-900">{lineCount}</p>
        </Card>
      </div>

      <Card className="overflow-hidden mb-6">
        <textarea
          className="w-full h-80 p-4 resize-y focus:outline-none focus:ring-0 border-none"
          placeholder="Type or paste your text here..."
          value={text}
          onChange={(e) => setText(e.target.value)}
        ></textarea>
        <div className="bg-slate-50 p-3 border-t border-slate-200 flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={() => setText("")} disabled={!text}>
            <Trash className="w-4 h-4 mr-2" />
            Clear
          </Button>
          <Button size="sm" onClick={() => navigator.clipboard.writeText(text)} disabled={!text}>
            <Copy className="w-4 h-4 mr-2" />
            Copy Text
          </Button>
        </div>
      </Card>
      
      <div className="prose prose-slate max-w-none mt-12">
        <h2>About this tool</h2>
        <p>
          Our Word Counter is a free online tool that calculates the number of words, characters, sentences, and lines in your text. 
          It processes everything entirely in your browser—no data is sent to our servers.
        </p>
      </div>
    </div>
  );
}
