import React from "react";
import { SEO } from "../components/SEO";

export function AboutPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16 prose prose-slate">
      <SEO title="About Us" description="Learn more about FileTools Hub and our mission to provide free online file tools." />
      
      <h1>About FileTools Hub</h1>
      <p>
        FileTools Hub provides completely free online tools for working with PDFs, images, documents, and text. 
        Our mission is to simplify file management and formatting without requiring users to download expensive software.
      </p>
      
      <h2>Our Story</h2>
      <p>
        We noticed that many online tools are cluttered with ads, have strict hidden limits, or require you to create an account for basic tasks. 
        We decided to build a platform that focuses on user experience, speed, and privacy.
      </p>
      
      <h2>Privacy First</h2>
      <p>
        We believe your data belongs to you. That's why files processed through our servers are automatically deleted 
        after a short period (typically 1 hour). We do not inspect, sell, or permanently store your uploaded files.
      </p>
    </div>
  );
}
