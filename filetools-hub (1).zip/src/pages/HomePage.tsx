import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { setSharedFiles } from "../lib/fileStore";
import { useRef } from "react";
import { 
  FileText, ImageIcon, Type, Search, UploadCloud, 
  ChevronDown, ShieldCheck, Zap, ThumbsUp, DollarSign,
  Minimize2, FileOutput, FilePlus, FileMinus
} from "lucide-react";
import { SEO } from "../components/SEO";
import { getSiteUrl } from "../utils/site";
import { Button } from "../components/ui/Button";
import { Card, CardHeader, CardTitle, CardDescription } from "../components/ui/Card";
import { AdSlot } from "../components/AdSlot";
import { blogPosts } from "../data/blog";
import { ChevronRight } from "lucide-react";
import { cn } from "../lib/utils";

export function HomePage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFiles = (fileList: FileList | File[]) => {
    const filesArray = Array.from(fileList) as File[];
    if (filesArray.length === 0) return;
    
    setSharedFiles(filesArray);
    const type = filesArray[0].type;
    if (type.startsWith("image/")) {
      navigate("/jpg-to-pdf");
    } else if (type === "application/pdf") {
      navigate("/split-pdf");
    } else {
      navigate("/tools");
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };


  const tools = [
    { name: "JPG to PDF", desc: "Convert images to PDF.", category: "PDF Tools", icon: <FilePlus className="w-6 h-6 text-indigo-500" />, path: "/jpg-to-pdf" },
    { name: "PDF to JPG", desc: "Convert PDF pages to images.", category: "PDF Tools", icon: <FileOutput className="w-6 h-6 text-indigo-500" />, path: "/pdf-to-jpg" },
    { name: "Merge PDF", desc: "Combine multiple PDFs.", category: "PDF Tools", icon: <FileText className="w-6 h-6 text-indigo-500" />, path: "/merge-pdf" },
    { name: "Split PDF", desc: "Extract PDF pages.", category: "PDF Tools", icon: <FileMinus className="w-6 h-6 text-indigo-500" />, path: "/split-pdf" },
    { name: "Compress PDF", desc: "Reduce PDF file size.", category: "PDF Tools", icon: <Minimize2 className="w-6 h-6 text-indigo-500" />, path: "/compress-pdf" },
    { name: "Text to PDF", desc: "Generate PDF from text.", category: "PDF Tools", icon: <Type className="w-6 h-6 text-indigo-500" />, path: "/text-to-pdf" },
    { name: "Image Compressor", desc: "Reduce image file size.", category: "Image Tools", icon: <Minimize2 className="w-6 h-6 text-indigo-500" />, path: "/image-compressor" },
    { name: "Image Resizer", desc: "Resize JPG, PNG, WEBP.", category: "Image Tools", icon: <ImageIcon className="w-6 h-6 text-indigo-500" />, path: "/image-resizer" },
    { name: "Image Converter", desc: "Convert WebP, PNG, JPG.", category: "Image Tools", icon: <ImageIcon className="w-6 h-6 text-indigo-500" />, path: "/image-converter" },
    { name: "Word Counter", desc: "Count words, characters & lines.", category: "Text Tools", icon: <Type className="w-6 h-6 text-indigo-500" />, path: "/word-counter" },
    { name: "Case Converter", desc: "Convert uppercase, lowercase, camelCase, etc.", category: "Text Tools", icon: <Type className="w-6 h-6 text-indigo-500" />, path: "/case-converter" },
  ];

  const filteredTools = tools.filter(tool => 
    tool.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    tool.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const faqs = [
    { q: "Is FileTools Hub free?", a: "Yes, FileTools Hub is completely free to use with no hidden fees." },
    { q: "Which file formats are supported?", a: "We support a wide variety of formats including PDF, JPG, PNG, and WEBP." },
    { q: "Are my uploaded files stored?", a: "No, files are automatically and permanently deleted from our servers shortly after processing." },
    { q: "Can I use FileTools Hub on mobile?", a: "Yes, our website is fully optimized for mobile devices and tablets." },
    { q: "Do I need to create an account?", a: "No registration is required. You can start using our tools immediately." }
  ];

  const toggleFaq = (index: number) => {
    if (openFaq === index) {
      setOpenFaq(null);
    } else {
      setOpenFaq(index);
    }
  };

  const homeStructuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "WebSite",
        "@id": `${getSiteUrl()}/#website`,
        "url": `${getSiteUrl()}/`,
        "name": "FileTools Hub",
        "description": "Free online tools to convert, compress, resize, merge and manage PDF, image, and text files.",
        "potentialAction": {
          "@type": "SearchAction",
          "target": `${getSiteUrl()}/tools?search={search_term_string}`,
          "query-input": "required name=search_term_string"
        }
      },
      {
        "@type": "Organization",
        "@id": `${getSiteUrl()}/#organization`,
        "name": "FileTools Hub",
        "url": `${getSiteUrl()}/`,
        "logo": `${getSiteUrl()}/favicon.svg`
      }
    ]
  };

  return (
    <>
      <SEO 
        title="Free Online PDF & Image Tools" 
        description="Free online tools to convert, compress, resize, merge and manage PDF and image files quickly and easily."
        structuredData={homeStructuredData}
      />
      
      {/* Hero Section */}
      <section className="bg-slate-50 border-b border-slate-200 pt-6 md:pt-10 pb-12 md:pb-16 px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-semibold text-slate-900 tracking-tight mb-4">
            All Your File Tools in One Place
          </h1>
          <p className="text-lg md:text-xl text-slate-600 mb-6 max-w-2xl mx-auto">
            Convert, compress, resize, merge and manage your files quickly and easily.
          </p>
          
          <div className="max-w-3xl mx-auto mb-10">
            <div className="text-center mb-6">
              <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-2 tracking-tight">
                JPG to PDF
              </h2>
              <p className="text-base md:text-lg text-slate-600">
                Convert JPG images to PDF in seconds. Easily adjust orientation and margins.
              </p>
            </div>

            <div 
              className={cn("bg-blue-600 rounded-xl p-6 shadow-md transition-colors relative", dragActive && "bg-blue-700")}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <div className="border-[3px] border-dashed border-white/60 rounded-xl p-8 md:p-12 text-center relative flex flex-col items-center min-h-[300px] justify-center">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFiles}
                  className="hidden"
                  title="Choose files"
                />
                
                <div className="flex justify-center mb-8 pointer-events-none">
                  <svg width="120" height="120" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-95">
                    <path d="M44 32H28C25.7909 32 24 33.7909 24 36V76C24 78.2091 25.7909 80 28 80H84C86.2091 80 88 78.2091 88 76V56" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M72 44V28C72 25.7909 70.2091 24 68 24H52C49.7909 24 48 25.7909 48 28V68C48 70.2091 49.7909 72 52 72H68C70.2091 72 72 70.2091 72 68V60" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M60 48H88C90.2091 48 92 49.7909 92 52V88C92 90.2091 90.2091 92 88 92H60C57.7909 92 56 90.2091 56 88V52C56 49.7909 57.7909 48 60 48Z" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M68 60L72 56M72 56L76 60M72 56V68" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M60 82H88" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <path d="M36 64H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <path d="M36 56H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <path d="M36 48H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <path d="M56 36H64" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <path d="M56 44H64" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                    <rect x="48" y="70" width="34" height="18" fill="white" rx="3" />
                    <text x="52" y="83" fill="#2563eb" fontSize="12" fontWeight="bold" fontFamily="sans-serif">FILE</text>
                  </svg>
                </div>

                <button 
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex rounded-md overflow-hidden shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] active:scale-95 focus:outline-none focus:ring-4 focus:ring-white/50"
                >
                  <div className="px-6 md:px-8 py-4 md:py-5 flex items-center justify-center gap-3 bg-[#f3f4f6] text-slate-900 font-extrabold text-xl md:text-2xl border-r border-slate-300">
                    <FilePlus className="w-6 h-6 md:w-8 md:h-8" />
                    CHOOSE FILES
                  </div>
                  <div className="px-4 py-4 md:py-5 flex items-center justify-center bg-white hover:bg-slate-50 transition-colors">
                    <ChevronDown className="w-6 h-6 md:w-8 md:h-8 text-slate-900" />
                  </div>
                </button>
              </div>
            </div>
          </div>

          
          <p className="text-sm font-medium text-slate-500">
            Free • Fast • Secure • No registration required
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <AdSlot type="header" className="mb-12" />

        {/* Tools Section */}
        <section id="tools" className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Popular File Tools</h2>
            <p className="text-slate-600">Explore our collection of free file management utilities.</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTools.length > 0 ? filteredTools.map((tool, i) => (
              <Link to={tool.path} key={i} className="block group">
                <Card className="h-full transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:border-indigo-200 bg-white">
                  <CardHeader>
                    <div className="flex items-center gap-4 mb-2">
                      <div className="bg-indigo-50 w-12 h-12 rounded-lg flex items-center justify-center group-hover:bg-indigo-100 transition-colors shrink-0">
                        {tool.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{tool.name}</CardTitle>
                        <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full uppercase tracking-wider">{tool.category}</span>
                      </div>
                    </div>
                    <CardDescription className="mt-2 text-slate-600 text-sm">
                      {tool.desc}
                    </CardDescription>
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <span className="text-sm font-medium text-indigo-600 group-hover:text-indigo-700 flex items-center">
                        Use Tool <span className="ml-1 group-hover:translate-x-1 transition-transform">→</span>
                      </span>
                    </div>
                  </CardHeader>
                </Card>
              </Link>
            )) : (
              <div className="col-span-full text-center py-10">
                <p className="text-slate-500">No tools found matching "{searchQuery}"</p>
              </div>
            )}
          </div>
        </section>

        <AdSlot type="middle" className="mb-16" />

        {/* Featured Tool / Upload Area */}
        <section className="mb-20">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Convert Your Files Easily</h2>
            <p className="text-slate-600">Choose a file and start using our fast online tools.</p>
          </div>
          
          <div className="max-w-3xl mx-auto bg-white border-2 border-dashed border-slate-300 rounded-2xl p-12 text-center hover:bg-slate-50 transition-colors shadow-sm">
            <UploadCloud className="w-16 h-16 text-indigo-500 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-slate-900 mb-2">Drag & Drop your files here</h3>
            <p className="text-slate-500 mb-6">or</p>
            <Link to="/tools">
              <Button size="lg" className="h-14 px-10 text-lg rounded-full">
                Choose Files
              </Button>
            </Link>
            <p className="text-sm text-slate-400 mt-6 font-medium">
              Supported formats: PDF, JPG, PNG, WEBP and more.
            </p>
          </div>
        </section>

        {/* How It Works */}
        <section className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">How It Works</h2>
            <p className="text-slate-600">Get your files ready in 3 simple steps.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center max-w-4xl mx-auto relative">
            {/* Background line connecting steps on md+ */}
            <div className="hidden md:block absolute top-8 left-[16%] right-[16%] h-[2px] bg-indigo-100 z-0"></div>
            
            <div className="relative z-10">
              <div className="w-16 h-16 bg-indigo-600 text-white font-bold text-2xl rounded-full flex items-center justify-center mx-auto mb-6 shadow-md border-4 border-white">01</div>
              <h3 className="font-bold text-xl mb-2">Choose a Tool</h3>
              <p className="text-slate-600">Select the file tool you need.</p>
            </div>
            
            <div className="relative z-10">
              <div className="w-16 h-16 bg-indigo-600 text-white font-bold text-2xl rounded-full flex items-center justify-center mx-auto mb-6 shadow-md border-4 border-white">02</div>
              <h3 className="font-bold text-xl mb-2">Upload Your File</h3>
              <p className="text-slate-600">Upload your document or image.</p>
            </div>
            
            <div className="relative z-10">
              <div className="w-16 h-16 bg-indigo-600 text-white font-bold text-2xl rounded-full flex items-center justify-center mx-auto mb-6 shadow-md border-4 border-white">03</div>
              <h3 className="font-bold text-xl mb-2">Download Result</h3>
              <p className="text-slate-600">Process your file and download the result.</p>
            </div>
          </div>
        </section>

        {/* Why FileTools Hub */}
        <section className="bg-indigo-50 rounded-3xl p-8 md:p-12 mb-20 text-center shadow-inner">
          <h2 className="text-3xl font-bold text-slate-900 mb-10">Why FileTools Hub</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="bg-indigo-50 w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Fast Processing</h3>
              <p className="text-slate-600 text-sm">Lightning-fast cloud processing servers.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="bg-indigo-50 w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-4">
                <ThumbsUp className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Easy to Use</h3>
              <p className="text-slate-600 text-sm">Intuitive interface designed for everyone.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="bg-indigo-50 w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-4">
                <ShieldCheck className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Secure Processing</h3>
              <p className="text-slate-600 text-sm">Files are deleted shortly after processing.</p>
            </div>
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className="bg-indigo-50 w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-4">
                <DollarSign className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="font-semibold text-lg mb-2">Free Tools</h3>
              <p className="text-slate-600 text-sm">No hidden fees or subscriptions required.</p>
            </div>
          </div>
        </section>

        
        {/* Latest from the Blog */}
        <section className="mb-20">
          <div className="flex flex-col md:flex-row justify-between items-end mb-10 gap-4">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Latest from the Blog</h2>
              <p className="text-slate-600">Guides, tutorials, and tips for managing your files.</p>
            </div>
            <Link to="/blog">
              <Button variant="outline" className="flex items-center">
                View All Articles <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {blogPosts.slice(0, 3).map((post) => (
              <Link to={`/blog/${post.slug}`} key={post.slug} className="group flex flex-col h-full bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all hover:-translate-y-1">
                <div className="aspect-video w-full overflow-hidden relative">
                  <img 
                    src={post.thumbnail} 
                    alt={post.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-semibold text-indigo-700">
                    {post.category}
                  </div>
                </div>
                <div className="p-6 flex flex-col flex-grow">
                  <h3 className="text-xl font-bold text-slate-900 mb-3 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-slate-600 text-sm line-clamp-2 mb-4 flex-grow">
                    {post.excerpt}
                  </p>
                  <div className="text-indigo-600 font-semibold text-sm mt-auto">
                    Read Article &rarr;
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* FAQ Section */}
        <section className="mb-16 max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="border border-slate-200 rounded-lg bg-white overflow-hidden">
                <button 
                  className="w-full text-left px-6 py-4 flex items-center justify-between font-semibold text-slate-900 focus:outline-none hover:bg-slate-50 transition-colors"
                  onClick={() => toggleFaq(index)}
                >
                  {faq.q}
                  <ChevronDown className={`w-5 h-5 text-slate-500 transition-transform duration-200 ${openFaq === index ? 'rotate-180' : ''}`} />
                </button>
                <div 
                  className={`px-6 text-slate-600 overflow-hidden transition-all duration-300 ${openFaq === index ? 'max-h-40 pb-4 opacity-100' : 'max-h-0 opacity-0'}`}
                >
                  {faq.a}
                </div>
              </div>
            ))}
          </div>
        </section>

      </div>
    </>
  );
}
