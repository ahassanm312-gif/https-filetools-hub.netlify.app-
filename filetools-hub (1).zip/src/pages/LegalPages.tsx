import React from "react";
import { SEO } from "../components/SEO";

export function LegalPages({ type }: { type: 'privacy' | 'terms' | 'cookie' | 'disclaimer' }) {
  let content = { title: "", desc: "", body: <></> };

  if (type === 'privacy') {
    content = {
      title: "Privacy Policy",
      desc: "Information about how we handle your data.",
      body: (
        <>
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <h2>1. Information We Collect</h2>
          <p>When you use our services, we may collect minimal technical data such as your IP address, browser type, and usage statistics to improve our tools.</p>
          <h2>2. File Uploads and Processing</h2>
          <p>Any files you upload are processed entirely automatically. Files are kept on our temporary secure servers for a maximum of 1 hour to allow you time to download the processed result, after which they are permanently and irreversibly deleted.</p>
          <h2>3. Third-Party Services</h2>
          <p>We use third-party analytics and advertising services (such as Google AdSense) which may use cookies to serve ads based on your prior visits.</p>
        </>
      )
    };
  } else if (type === 'terms') {
    content = {
      title: "Terms of Service",
      desc: "Rules and guidelines for using FileTools Hub.",
      body: (
        <>
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <h2>1. Acceptance of Terms</h2>
          <p>By accessing or using FileTools Hub, you agree to be bound by these Terms of Service.</p>
          <h2>2. Acceptable Use</h2>
          <p>You agree not to use the service for any illegal or unauthorized purpose. You must not upload files containing malware, illegal content, or files that infringe on copyright laws.</p>
          <h2>3. Service Availability</h2>
          <p>While we strive to provide 100% uptime, our services are provided "as is" and we are not responsible for any data loss, interruptions, or errors during processing.</p>
        </>
      )
    };
  } else if (type === 'cookie') {
    content = {
      title: "Cookie Policy",
      desc: "Information about our use of cookies.",
      body: (
        <>
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <h2>1. What Are Cookies?</h2>
          <p>Cookies are small text files placed on your device to help the site provide a better user experience.</p>
          <h2>2. How We Use Cookies</h2>
          <p>We use cookies to retain user preferences, track analytics, and provide targeted advertising through third-party services like Google AdSense and Adsterra.</p>
        </>
      )
    };
  } else if (type === 'disclaimer') {
    content = {
      title: "Disclaimer",
      desc: "Legal disclaimer for FileTools Hub.",
      body: (
        <>
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <h2>General Information</h2>
          <p>The tools and information provided on FileTools Hub are for general informational and utility purposes only.</p>
          <h2>No Warranty</h2>
          <p>We make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability of the tools provided.</p>
        </>
      )
    };
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-16 prose prose-slate">
      <SEO title={content.title} description={content.desc} />
      <h1>{content.title}</h1>
      {content.body}
    </div>
  );
}
