import { apiFetch, getApiUrl } from "../utils/api";
import React, { useState, useRef, useEffect } from "react";
import { getSharedFiles } from "../lib/fileStore";
import { SEO } from "../components/SEO";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, Trash2, GripVertical, FilePlus, ChevronDown } from "lucide-react";
import { AdSlot } from "../components/AdSlot";
import { cn } from "../lib/utils";

export function ImageToPdfPage() {
  const [files, setFiles] = useState<File[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ downloadUrl: string; filename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  useEffect(() => {
    const shared = getSharedFiles();
    if (shared.length > 0) {
      processFiles(shared);
    }
  }, []);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processFiles = (fileList: FileList | File[]) => {
    setError(null);
    const newFiles = Array.from(fileList);
    
    if (newFiles.length === 0) return;
    
    if (files.length + newFiles.length > 20) {
      setError(`Maximum 20 files allowed.`);
      return;
    }

    const invalidSize = newFiles.find(f => f.size > 100 * 1024 * 1024);
    if (invalidSize) {
      setError(`Files must be less than 100MB.`);
      return;
    }

    setFiles((prev) => [...prev, ...newFiles]);
    setResult(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleConvert = async () => {
    if (files.length === 0) {
      setError("Please select at least one image to convert.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    files.forEach(file => {
      formData.append("files", file);
    });

    try {
      const data = await apiFetch<{ downloadUrl: string; filename: string; newSize: number }>(
        "/api/pdf/image-to-pdf",
        {
          method: "POST",
          body: formData,
        }
      );
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 md:py-12">
      <SEO 
        title="JPG to PDF - Convert JPG images to PDF in seconds" 
        description="Convert JPG images to PDF in seconds. Easily adjust orientation and margins." 
      />
      
      {/* Breadcrumbs */}
      <div className="text-sm font-medium text-slate-500 mb-6 flex items-center justify-center">
        <a href="/" className="hover:text-indigo-600 transition-colors">Home</a>
        <span className="mx-2">›</span>
        <span className="text-slate-800">JPG to PDF</span>
      </div>

      <div className="text-center mb-8">
        <h1 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">JPG to PDF</h1>
        <p className="text-lg text-slate-600">Convert JPG images to PDF in seconds. Easily adjust orientation and margins.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!result && files.length === 0 && (
        <div className="max-w-3xl mx-auto mb-10">
          <div 
            className={cn(
              "bg-blue-600 rounded-xl p-6 shadow-md transition-colors",
              dragActive && "bg-blue-700"
            )}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <div className="border-[3px] border-dashed border-white/60 rounded-xl p-12 text-center relative flex flex-col items-center min-h-[360px] justify-center">
              <input
                ref={inputRef}
                type="file"
                multiple
                accept="image/jpeg,image/png,image/webp"
                onChange={handleChange}
                className="hidden"
                title="Choose files"
              />
              
              <div className="flex justify-center mb-10 pointer-events-none">
                <svg width="140" height="140" viewBox="0 0 120 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="opacity-95">
                  <path d="M44 32H28C25.7909 32 24 33.7909 24 36V76C24 78.2091 25.7909 80 28 80H84C86.2091 80 88 78.2091 88 76V56" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M72 44V28C72 25.7909 70.2091 24 68 24H52C49.7909 24 48 25.7909 48 28V68C48 70.2091 49.7909 72 52 72H68C70.2091 72 72 70.2091 72 68V60" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M60 48H88C90.2091 48 92 49.7909 92 52V88C92 90.2091 90.2091 92 88 92H60C57.7909 92 56 90.2091 56 88V52C56 49.7909 57.7909 48 60 48Z" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M68 60L72 56M72 56L76 60M72 56V68" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M60 82H88" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M36 64H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M36 56H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M36 48H44" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M56 36H64" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <path d="M56 44H64" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
                  <rect x="48" y="70" width="34" height="18" fill="white" rx="3" />
                  <text x="52" y="83" fill="#2563eb" fontSize="12" fontWeight="bold" fontFamily="sans-serif">PDF</text>
                </svg>
              </div>

              <button 
                type="button"
                onClick={() => inputRef.current?.click()}
                className="inline-flex rounded-md overflow-hidden shadow-lg hover:shadow-xl transition-all hover:scale-[1.02] active:scale-95 focus:outline-none focus:ring-4 focus:ring-white/50"
              >
                <div className="px-8 py-5 flex items-center justify-center gap-3 bg-[#f3f4f6] text-slate-900 font-extrabold text-xl sm:text-2xl border-r border-slate-300">
                  <FilePlus className="w-6 h-6 sm:w-8 sm:h-8" />
                  CHOOSE FILES
                </div>
                <div className="px-5 py-5 flex items-center justify-center bg-white hover:bg-slate-50 transition-colors">
                  <ChevronDown className="w-6 h-6 sm:w-8 sm:h-8 text-slate-900" />
                </div>
              </button>
              
              {error && (
                <div className="absolute bottom-4 bg-red-100 text-red-700 px-4 py-2 rounded-md font-medium text-sm">
                  {error}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {!result && files.length > 0 && (
        <div className="max-w-3xl mx-auto">
          <Card className="p-6">
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-slate-900 text-lg">Selected Images ({files.length})</h3>
                <Button variant="outline" size="sm" onClick={() => inputRef.current?.click()}>
                  <FilePlus className="w-4 h-4 mr-2" />
                  Add More
                </Button>
                <input
                  ref={inputRef}
                  type="file"
                  multiple
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleChange}
                  className="hidden"
                />
              </div>
              
              <ul className="divide-y divide-slate-100 max-h-96 overflow-y-auto border border-slate-200 rounded-lg">
                {files.map((file, i) => (
                  <li key={i} className="py-3 px-4 flex items-center justify-between group hover:bg-slate-50">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <GripVertical className="w-4 h-4 text-slate-300 cursor-move shrink-0" />
                      <span className="truncate max-w-[200px] sm:max-w-md text-sm font-medium text-slate-700">{file.name}</span>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => removeFile(i)} className="text-red-500 hover:text-red-700 hover:bg-red-50 shrink-0">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </li>
                ))}
              </ul>

              {error && (
                <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm font-medium">
                  {error}
                </div>
              )}

              <Button 
                size="lg" 
                className="w-full mt-4 h-14 text-lg bg-[#eab308] hover:bg-[#dca506] text-slate-900 border-none shadow-md hover:shadow-lg" 
                onClick={handleConvert}
                disabled={isProcessing || files.length === 0}
              >
                {isProcessing ? (
                  <><Loader2 className="mr-3 h-6 w-6 animate-spin" /> Converting to PDF...</>
                ) : (
                  "Convert to PDF"
                )}
              </Button>
            </div>
          </Card>
        </div>
      )}

      {result && (
        <div className="max-w-3xl mx-auto">
          <Card className="text-center p-12 shadow-lg border-indigo-100">
            <div className="w-20 h-20 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Download className="w-10 h-10 text-indigo-600" />
            </div>
            <h3 className="text-3xl font-bold mb-8 text-slate-900">PDF Generated Successfully!</h3>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" className="h-14 px-8 text-lg" asChild>
                <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                  Download PDF
                </a>
              </Button>
              <Button variant="outline" size="lg" className="h-14 px-8 text-lg" onClick={() => { setFiles([]); setResult(null); }}>
                <RefreshCw className="w-5 h-5 mr-2" />
                Convert More Images
              </Button>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
