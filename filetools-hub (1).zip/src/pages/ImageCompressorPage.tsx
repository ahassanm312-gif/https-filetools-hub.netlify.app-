import { apiFetch, getApiUrl } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { FileUpload } from "../components/FileUpload";
import { Button } from "../components/ui/Button";
import { Card, CardContent } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, AlertCircle } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function ImageCompressorPage() {
  const [file, setFile] = useState<File | null>(null);
  const [quality, setQuality] = useState(80);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ originalSize: number; newSize: number; downloadUrl: string; filename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (files: File[]) => {
    setFile(files[0]);
    setResult(null);
    setError(null);
  };

  const handleCompress = async () => {
    if (!file) return;

    setIsProcessing(true);
    setError(null);
    
    const formData = new FormData();
    formData.append("file", file);
    formData.append("quality", quality.toString());
    formData.append("format", "jpeg");

    try {
      const data = await apiFetch<{ originalSize: number; newSize: number; downloadUrl: string; filename: string }>(
        "/api/image/compress",
        {
          method: "POST",
          body: formData,
        }
      );
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Image Compressor" 
        description="Compress JPG, PNG, WEBP images online without losing quality. Reduce file size instantly." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Compress Image</h1>
        <p className="text-slate-600">Reduce your image file size easily online.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!file && !result && (
        <FileUpload 
          onFilesSelected={handleFileSelect} 
          accept="image/jpeg, image/png, image/webp" 
          maxSizeMB={20}
        />
      )}

      {file && !result && (
        <Card className="p-6">
          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4">
              <div>
                <p className="font-medium text-slate-900 truncate max-w-[200px] sm:max-w-md">{file.name}</p>
                <p className="text-sm text-slate-500">{formatBytes(file.size)}</p>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setFile(null)}>Remove</Button>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Compression Quality: {quality}%
              </label>
              <input 
                type="range" 
                min="10" 
                max="100" 
                value={quality}
                onChange={(e) => setQuality(parseInt(e.target.value))}
                className="w-full accent-indigo-600"
              />
              <p className="text-xs text-slate-500 mt-2">Lower quality means smaller file size.</p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm font-medium">
                {error}
              </div>
            )}

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleCompress}
              disabled={isProcessing}
            >
              {isProcessing ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing...</>
              ) : (
                "Compress Image"
              )}
            </Button>
          </div>
        </Card>
      )}

      {result && (
        <Card className="text-center p-10">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Download className="w-8 h-8 text-green-600" />
          </div>
          <h3 className="text-2xl font-bold mb-2">Image Compressed Successfully!</h3>
          
          <div className="flex justify-center gap-8 mb-8">
            <div>
              <p className="text-sm text-slate-500">Original Size</p>
              <p className="font-semibold">{formatBytes(result.originalSize)}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">New Size</p>
              <p className="font-semibold text-green-600">{formatBytes(result.newSize)}</p>
            </div>
            <div>
              <p className="text-sm text-slate-500">Saved</p>
              <p className="font-semibold">{Math.round((1 - result.newSize / result.originalSize) * 100)}%</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                Download File
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={() => { setFile(null); setResult(null); }}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Compress Another
            </Button>
          </div>
        </Card>
      )}

      <AdSlot type="middle" className="my-12" />

      <div className="prose prose-slate max-w-none mt-12">
        <h2>How to Compress an Image?</h2>
        <ol>
          <li>Click the upload box or drag and drop your image file.</li>
          <li>Adjust the compression quality slider based on your needs.</li>
          <li>Click on "Compress Image" to start processing.</li>
          <li>Download your optimized image instantly.</li>
        </ol>
        
        <h3>Frequently Asked Questions</h3>
        <div className="space-y-4 mt-6">
          <div>
            <h4 className="font-semibold text-slate-900">Are my files secure?</h4>
            <p className="text-sm text-slate-600 mt-1">Yes, all files are processed securely and deleted automatically from our servers after 1 hour.</p>
          </div>
          <div>
            <h4 className="font-semibold text-slate-900">What formats are supported?</h4>
            <p className="text-sm text-slate-600 mt-1">We support JPG, JPEG, PNG, and WEBP formats for compression.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
