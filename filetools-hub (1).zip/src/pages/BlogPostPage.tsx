import React, { useEffect } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import { SEO } from "../components/SEO";
import { blogPosts } from "../data/blog";
import { Button } from "../components/ui/Button";
import { ChevronRight, ArrowLeft, Calendar, Tag, Zap } from "lucide-react";
import { Helmet } from "react-helmet-async";
import { getSiteUrl, getCanonicalUrl } from "../utils/site";

export function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const post = blogPosts.find((p) => p.slug === slug);

  // Scroll to top on load
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!post) {
    return <Navigate to="/blog" replace />;
  }

  const relatedArticles = blogPosts
    .filter((p) => p.category === post.category && p.slug !== post.slug)
    .slice(0, 3);

  const formattedDate = new Date(post.publishedAt).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric"
  });

  const siteUrl = getSiteUrl();
  const canonical = getCanonicalUrl(`/blog/${post.slug}`);

  const structuredData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BlogPosting",
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": canonical
        },
        "headline": post.title,
        "image": [post.thumbnail],
        "datePublished": post.publishedAt,
        "dateModified": post.publishedAt,
        "author": {
          "@type": "Organization",
          "name": "FileTools Hub",
          "url": siteUrl
        },
        "publisher": {
          "@type": "Organization",
          "name": "FileTools Hub",
          "url": siteUrl,
          "logo": {
            "@type": "ImageObject",
            "url": `${siteUrl}/favicon.svg`
          }
        },
        "description": post.excerpt
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": `${siteUrl}/`
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Blog",
            "item": `${siteUrl}/blog`
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": post.title,
            "item": canonical
          }
        ]
      }
    ]
  };

  return (
    <>
      <SEO 
        title={`${post.title} - FileTools Hub Blog`}
        description={post.excerpt}
        canonicalUrl={canonical}
        type="article"
        structuredData={structuredData}
      />
      <Helmet>
        <meta property="article:published_time" content={post.publishedAt} />
        <meta property="article:section" content={post.category} />
      </Helmet>

      {/* Hero Section */}
      <div className="bg-slate-50 border-b border-slate-200 py-10 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Breadcrumb */}
          <nav className="flex text-sm text-slate-500 mb-6" aria-label="Breadcrumb">
            <Link to="/" className="hover:text-indigo-600 transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/blog" className="hover:text-indigo-600 transition-colors">Blog</Link>
            <span className="mx-2">/</span>
            <span className="text-slate-900 font-medium truncate">{post.title}</span>
          </nav>
          
          <div className="flex items-center gap-4 mb-4 text-sm font-medium">
            <span className="text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full flex items-center">
              <Tag className="w-4 h-4 mr-1.5" />
              {post.category}
            </span>
            <span className="text-slate-500 flex items-center">
              <Calendar className="w-4 h-4 mr-1.5" />
              {formattedDate}
            </span>
          </div>

          <h1 className="text-3xl md:text-5xl font-extrabold text-slate-900 tracking-tight mb-6 leading-tight">
            {post.title}
          </h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Featured Image */}
        <div className="rounded-2xl overflow-hidden mb-12 shadow-md">
          <img 
            src={post.thumbnail} 
            alt={post.title} 
            className="w-full h-auto aspect-video object-cover"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-8">
            <article 
              className="prose prose-slate prose-indigo max-w-none prose-headings:font-bold prose-h2:text-2xl prose-h2:mt-10 prose-p:text-slate-700 prose-p:leading-relaxed prose-a:text-indigo-600 prose-img:rounded-xl"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />
            
            {/* CTA Box */}
            {post.relatedToolPath && post.relatedToolName && (
              <div className="mt-12 p-8 bg-indigo-50 rounded-2xl border border-indigo-100 text-center">
                <div className="w-12 h-12 bg-indigo-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                  <Zap className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-3">Ready to try it yourself?</h3>
                <p className="text-slate-600 mb-6 max-w-md mx-auto">
                  Use our free, secure, and blazing fast {post.relatedToolName} tool right in your browser.
                </p>
                <Link to={post.relatedToolPath}>
                  <Button size="lg" className="rounded-full px-8 text-base">
                    Try {post.relatedToolName} Now
                  </Button>
                </Link>
              </div>
            )}
            
            <div className="mt-12 pt-8 border-t border-slate-200">
              <Link to="/blog">
                <Button variant="outline" className="flex items-center">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to All Articles
                </Button>
              </Link>
            </div>
          </div>

          {/* Sidebar / Related */}
          <div className="lg:col-span-4">
            <div className="sticky top-24">
              <h3 className="text-lg font-bold text-slate-900 mb-6 border-b border-slate-200 pb-3">
                Related Articles
              </h3>
              
              {relatedArticles.length > 0 ? (
                <div className="space-y-6">
                  {relatedArticles.map((rel) => (
                    <Link to={`/blog/${rel.slug}`} key={rel.slug} className="group flex gap-4 items-start">
                      <div className="w-24 h-20 shrink-0 overflow-hidden rounded-lg bg-slate-100">
                        <img 
                          src={rel.thumbnail} 
                          alt={rel.title} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          loading="lazy"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-2 mb-1">
                          {rel.title}
                        </h4>
                        <span className="text-xs text-slate-500 font-medium">
                          {new Date(rel.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-slate-500">Check back regularly for more articles in this category.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
