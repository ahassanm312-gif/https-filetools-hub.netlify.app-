import React, { useState, useMemo } from "react";
import { SEO } from "../components/SEO";
import { Button } from "../components/ui/Button";
import { Card, CardContent } from "../components/ui/Card";
import { Copy, Check, Download, Trash2, ArrowUpRight, ArrowDownUp, RefreshCw, Type } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

type CaseMode =
  | "uppercase"
  | "lowercase"
  | "sentence"
  | "title"
  | "capitalize"
  | "camel"
  | "pascal"
  | "snake"
  | "kebab"
  | "constant"
  | "dot"
  | "alternating"
  | "inverse";

interface ModeOption {
  id: CaseMode;
  label: string;
  sample: string;
  desc: string;
}

const MODES: ModeOption[] = [
  { id: "uppercase", label: "UPPERCASE", sample: "HELLO WORLD", desc: "All letters in capital uppercase" },
  { id: "lowercase", label: "lowercase", sample: "hello world", desc: "All letters in lowercase" },
  { id: "sentence", label: "Sentence case", sample: "Hello world", desc: "First letter of each sentence capitalized" },
  { id: "title", label: "Title Case", sample: "Hello World", desc: "Capitalize major words" },
  { id: "capitalize", label: "Capitalize Each Word", sample: "Hello World", desc: "First letter of every word capitalized" },
  { id: "camel", label: "camelCase", sample: "helloWorld", desc: "First word lowercase, rest capitalized" },
  { id: "pascal", label: "PascalCase", sample: "HelloWorld", desc: "Every word capitalized with no spaces" },
  { id: "snake", label: "snake_case", sample: "hello_world", desc: "Lowercase words separated by underscores" },
  { id: "kebab", label: "kebab-case", sample: "hello-world", desc: "Lowercase words separated by hyphens" },
  { id: "constant", label: "CONSTANT_CASE", sample: "HELLO_WORLD", desc: "Uppercase words separated by underscores" },
  { id: "dot", label: "dot.case", sample: "hello.world", desc: "Lowercase words separated by dots" },
  { id: "alternating", label: "aLtErNaTiNg CaSe", sample: "hElLo wOrLd", desc: "Alternating lower and upper characters" },
  { id: "inverse", label: "InVeRsE CaSe", sample: "iNvErSe cAsE", desc: "Invert uppercase to lowercase and vice-versa" },
];

function getWords(text: string): string[] {
  return text
    .replace(/([a-z])([A-Z])/g, "$1 $2")
    .split(/[^a-zA-Z0-9]+/)
    .filter(Boolean);
}

const MINOR_WORDS = new Set([
  "a", "an", "the", "and", "but", "or", "nor", "for", "at", "by",
  "from", "in", "into", "of", "off", "on", "onto", "out", "over", "up", "with", "to", "as"
]);

export function convertCase(text: string, mode: CaseMode): string {
  if (!text) return "";

  switch (mode) {
    case "uppercase":
      return text.toUpperCase();

    case "lowercase":
      return text.toLowerCase();

    case "sentence":
      return text.toLowerCase().replace(/(^\s*|[.!?]\s*|\n\s*)([a-z])/g, (_, p1, p2) => p1 + p2.toUpperCase());

    case "title":
      return text.toLowerCase().replace(/\b([a-zA-Z]+)\b/g, (match, word, offset) => {
        const isFirst = offset === 0;
        if (!isFirst && MINOR_WORDS.has(word)) {
          return word;
        }
        return word.charAt(0).toUpperCase() + word.slice(1);
      });

    case "capitalize":
      return text.toLowerCase().replace(/\b([a-zA-Z0-9])/g, (c) => c.toUpperCase());

    case "camel": {
      const words = getWords(text);
      if (words.length === 0) return "";
      return (
        words[0].toLowerCase() +
        words
          .slice(1)
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
          .join("")
      );
    }

    case "pascal": {
      const words = getWords(text);
      return words.map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join("");
    }

    case "snake": {
      const words = getWords(text);
      return words.map((w) => w.toLowerCase()).join("_");
    }

    case "kebab": {
      const words = getWords(text);
      return words.map((w) => w.toLowerCase()).join("-");
    }

    case "constant": {
      const words = getWords(text);
      return words.map((w) => w.toUpperCase()).join("_");
    }

    case "dot": {
      const words = getWords(text);
      return words.map((w) => w.toLowerCase()).join(".");
    }

    case "alternating": {
      let toLower = true;
      let out = "";
      for (const char of text) {
        if (/[a-zA-Z]/.test(char)) {
          out += toLower ? char.toLowerCase() : char.toUpperCase();
          toLower = !toLower;
        } else {
          out += char;
        }
      }
      return out;
    }

    case "inverse": {
      let out = "";
      for (const char of text) {
        if (char === char.toUpperCase() && char !== char.toLowerCase()) {
          out += char.toLowerCase();
        } else if (char === char.toLowerCase() && char !== char.toUpperCase()) {
          out += char.toUpperCase();
        } else {
          out += char;
        }
      }
      return out;
    }

    default:
      return text;
  }
}

export function CaseConverterPage() {
  const [inputText, setInputText] = useState("");
  const [selectedMode, setSelectedMode] = useState<CaseMode>("uppercase");
  const [copied, setCopied] = useState(false);

  // Compute output text whenever input or mode changes
  const outputText = useMemo(() => {
    return convertCase(inputText, selectedMode);
  }, [inputText, selectedMode]);

  // Statistics calculation
  const getStats = (text: string) => {
    const trimmed = text.trim();
    const words = trimmed === "" ? 0 : trimmed.split(/\s+/).length;
    const chars = text.length;
    const lines = text === "" ? 0 : text.split(/\r\n|\r|\n/).length;
    return { words, chars, lines };
  };

  const inputStats = useMemo(() => getStats(inputText), [inputText]);
  const outputStats = useMemo(() => getStats(outputText), [outputText]);

  const handleCopy = async () => {
    const textToCopy = outputText || inputText;
    if (!textToCopy) return;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const textarea = document.createElement("textarea");
      textarea.value = textToCopy;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownload = () => {
    const textToDownload = outputText || inputText;
    if (!textToDownload) return;
    const blob = new Blob([textToDownload], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `converted_${selectedMode}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleReplaceInput = () => {
    if (!outputText) return;
    setInputText(outputText);
  };

  const handleClear = () => {
    setInputText("");
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Case Converter - FileTools Hub",
    "applicationCategory": "UtilitiesApplication",
    "operatingSystem": "All",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "description": "Free online case converter tool. Convert text to UPPERCASE, lowercase, Title Case, camelCase, snake_case, and more."
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 md:py-12">
      <SEO
        title="Case Converter - Free Online Text Case Tool"
        description="Easily convert text between UPPERCASE, lowercase, Title Case, camelCase, PascalCase, snake_case, kebab-case, and alternating case instantly."
        structuredData={structuredData}
      />

      {/* Breadcrumb */}
      <nav className="text-sm font-medium text-slate-500 mb-6 flex items-center" aria-label="Breadcrumb">
        <a href="/" className="hover:text-indigo-600 transition-colors">Home</a>
        <span className="mx-2">›</span>
        <a href="/tools?category=text" className="hover:text-indigo-600 transition-colors">Text Tools</a>
        <span className="mx-2">›</span>
        <span className="text-slate-900 font-semibold">Case Converter</span>
      </nav>

      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-100 text-indigo-600 mb-3 shadow-sm">
          <Type className="w-6 h-6" />
        </div>
        <h1 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
          Online Text Case Converter
        </h1>
        <p className="text-base md:text-lg text-slate-600 max-w-2xl mx-auto">
          Convert your text into uppercase, lowercase, sentence case, camelCase, snake_case, and 8 other formats instantly in your browser with zero server uploads.
        </p>
      </div>

      {/* Case Selector Buttons */}
      <div className="mb-8">
        <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 text-center sm:text-left">
          Select Target Case Format:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2">
          {MODES.map((mode) => {
            const isActive = selectedMode === mode.id;
            return (
              <button
                key={mode.id}
                id={`case-mode-${mode.id}`}
                type="button"
                onClick={() => setSelectedMode(mode.id)}
                className={`px-3 py-2.5 rounded-lg text-xs font-semibold transition-all text-center border flex flex-col items-center justify-center gap-0.5 ${
                  isActive
                    ? "bg-indigo-600 text-white border-indigo-600 shadow-sm ring-2 ring-indigo-200"
                    : "bg-white text-slate-700 border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50"
                }`}
                title={mode.desc}
                aria-pressed={isActive}
              >
                <span>{mode.label}</span>
                <span className={`text-[10px] font-normal truncate max-w-full opacity-75 ${isActive ? "text-indigo-100" : "text-slate-400"}`}>
                  {mode.sample}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dual Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Input Panel */}
        <Card className="border-slate-200 shadow-sm flex flex-col">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 rounded-t-xl">
            <div className="flex items-center gap-2">
              <label htmlFor="case-input-textarea" className="font-semibold text-sm text-slate-800">
                Input Text
              </label>
              <span className="text-xs text-slate-500">
                ({inputStats.words} words · {inputStats.chars} chars · {inputStats.lines} lines)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                id="btn-clear-input"
                onClick={handleClear}
                disabled={!inputText}
                className="text-xs text-slate-500 hover:text-red-600 disabled:opacity-40 disabled:hover:text-slate-500 flex items-center gap-1 font-medium transition-colors"
                aria-label="Clear input text"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>
            </div>
          </div>
          <CardContent className="p-0 flex-1">
            <textarea
              id="case-input-textarea"
              rows={10}
              className="w-full h-72 md:h-80 p-4 resize-y focus:outline-none focus:ring-2 focus:ring-indigo-500 border-0 rounded-b-xl text-slate-800 text-sm font-sans"
              placeholder="Paste or type your text here to convert case..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              aria-label="Input text for case conversion"
            />
          </CardContent>
        </Card>

        {/* Output Panel */}
        <Card className="border-slate-200 shadow-sm flex flex-col bg-white">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70 rounded-t-xl">
            <div className="flex items-center gap-2">
              <label htmlFor="case-output-textarea" className="font-semibold text-sm text-slate-800">
                Converted Output
              </label>
              <span className="text-xs text-indigo-600 font-medium">
                ({MODES.find((m) => m.id === selectedMode)?.label})
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">
                {outputStats.chars} chars
              </span>
            </div>
          </div>
          <CardContent className="p-0 flex-1">
            <textarea
              id="case-output-textarea"
              rows={10}
              readOnly
              className="w-full h-72 md:h-80 p-4 resize-y focus:outline-none border-0 rounded-b-xl text-slate-800 text-sm font-sans bg-slate-50/40"
              placeholder="Converted output will appear here automatically..."
              value={outputText}
              aria-label="Converted text output"
            />
          </CardContent>
          <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 rounded-b-xl">
            <div className="flex items-center gap-2">
              <Button
                type="button"
                id="btn-replace-input"
                variant="outline"
                size="sm"
                onClick={handleReplaceInput}
                disabled={!outputText}
                title="Use converted output as new input"
                className="text-xs"
              >
                <ArrowDownUp className="w-3.5 h-3.5 mr-1 text-slate-600" />
                Use as Input
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                id="btn-download-txt"
                variant="outline"
                size="sm"
                onClick={handleDownload}
                disabled={!outputText}
                className="text-xs"
              >
                <Download className="w-3.5 h-3.5 mr-1" />
                Download .TXT
              </Button>
              <Button
                type="button"
                id="btn-copy-output"
                size="sm"
                onClick={handleCopy}
                disabled={!outputText}
                className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 mr-1 text-green-200" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 mr-1" />
                    Copy Output
                  </>
                )}
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <AdSlot type="bottom" className="mb-8" />

      {/* Information & Feature Guide Section for SEO and Users */}
      <div className="mt-12 pt-8 border-t border-slate-200">
        <h2 className="text-2xl font-bold text-slate-900 mb-6 text-center md:text-left">
          About Our Text Case Converter
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm text-slate-600 mb-8">
          <div className="p-4 bg-white rounded-xl border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-2">100% Client-Side Privacy</h3>
            <p>Your text never leaves your browser. All transformations execute locally in JavaScript, guaranteeing maximum privacy and instant speed without network latency.</p>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-2">Developer & Code Ready</h3>
            <p>Easily transform strings to camelCase, PascalCase, snake_case, kebab-case, and CONSTANT_CASE for programming languages, APIs, and database migrations.</p>
          </div>
          <div className="p-4 bg-white rounded-xl border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-2">Editorial Title & Sentence Case</h3>
            <p>Format headlines, blog titles, and paragraphs with smart capitalization rules that respect English language conjunctions and prepositions.</p>
          </div>
        </div>

        {/* FAQs */}
        <h3 className="text-lg font-bold text-slate-900 mb-4">Frequently Asked Questions</h3>
        <div className="space-y-4 text-sm">
          <details className="p-4 bg-white rounded-lg border border-slate-200 cursor-pointer">
            <summary className="font-semibold text-slate-800">What is the difference between Title Case and Capitalize Each Word?</summary>
            <p className="mt-2 text-slate-600">Title Case formats titles according to editorial standards, keeping minor prepositions and conjunctions (like "and", "of", "the", "in") lowercase unless they begin the sentence. Capitalize Each Word capitalizes every single word regardless of part of speech.</p>
          </details>
          <details className="p-4 bg-white rounded-lg border border-slate-200 cursor-pointer">
            <summary className="font-semibold text-slate-800">Can I convert code identifiers?</summary>
            <p className="mt-2 text-slate-600">Yes! The tool intelligently parses variable names across camelCase, snake_case, and kebab-case, allowing you to convert between programming case conventions seamlessly.</p>
          </details>
          <details className="p-4 bg-white rounded-lg border border-slate-200 cursor-pointer">
            <summary className="font-semibold text-slate-800">Is there a character or word limit?</summary>
            <p className="mt-2 text-slate-600">No. Because all processing happens directly in your browser's memory, you can convert full essays, source code files, and book chapters without limits.</p>
          </details>
        </div>
      </div>
    </div>
  );
}
