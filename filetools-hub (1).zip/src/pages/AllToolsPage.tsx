import React from "react";
import { Link, useSearchParams } from "react-router-dom";
import { SEO } from "../components/SEO";
import { Card, CardHeader, CardTitle, CardDescription } from "../components/ui/Card";
import { FileText, Image as ImageIcon, Type, Minimize2 } from "lucide-react";

export function AllToolsPage() {
  const [searchParams] = useSearchParams();
  const categoryFilter = searchParams.get("category");

  const tools = [
    { name: "Image Compressor", desc: "Reduce image size online.", category: "image", icon: <Minimize2 />, path: "/image-compressor", available: true },
    { name: "Image Format Converter", desc: "Convert WebP, PNG, JPG.", category: "image", icon: <ImageIcon />, path: "/image-converter", available: true },
    { name: "Image Resizer", desc: "Resize JPG, PNG, WEBP.", category: "image", icon: <ImageIcon />, path: "/image-resizer", available: true },
    { name: "Merge PDF", desc: "Combine multiple PDFs.", category: "pdf", icon: <FileText />, path: "/merge-pdf", available: true },
    { name: "Compress PDF", desc: "Reduce PDF file size genuinely.", category: "pdf", icon: <FileText />, path: "/compress-pdf", available: true },
    { name: "JPG to PDF", desc: "Convert images to PDF.", category: "pdf", icon: <FileText />, path: "/jpg-to-pdf", available: true },
    { name: "PDF to JPG", desc: "Convert PDF pages to images.", category: "pdf", icon: <FileText />, path: "/pdf-to-jpg", available: true },
    { name: "Split PDF", desc: "Extract PDF pages.", category: "pdf", icon: <FileText />, path: "/split-pdf", available: true },
    { name: "Text to PDF", desc: "Generate PDF from text.", category: "text", icon: <Type />, path: "/text-to-pdf", available: true },
    { name: "Word Counter", desc: "Count words and characters.", category: "text", icon: <Type />, path: "/word-counter", available: true },
    { name: "Case Converter", desc: "Convert text between uppercase, lowercase, camelCase, snake_case, etc.", category: "text", icon: <Type />, path: "/case-converter", available: true },
  ];

  const filteredTools = categoryFilter 
    ? tools.filter(t => t.category === categoryFilter)
    : tools;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <SEO 
        title={categoryFilter ? `${categoryFilter.toUpperCase()} Tools` : "All Tools"} 
        description="Browse all our free online PDF, image, and text tools." 
      />
      
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">
          {categoryFilter ? `${categoryFilter.charAt(0).toUpperCase() + categoryFilter.slice(1)} Tools` : "All File Tools"}
        </h1>
        <p className="text-slate-600">Select a tool to get started for free.</p>
      </div>

      <div className="flex flex-wrap gap-2 justify-center mb-10">
        <Link to="/tools" className={`px-4 py-2 rounded-full text-sm font-medium ${!categoryFilter ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>All</Link>
        <Link to="/tools?category=pdf" className={`px-4 py-2 rounded-full text-sm font-medium ${categoryFilter === 'pdf' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>PDF Tools</Link>
        <Link to="/tools?category=image" className={`px-4 py-2 rounded-full text-sm font-medium ${categoryFilter === 'image' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>Image Tools</Link>
        <Link to="/tools?category=text" className={`px-4 py-2 rounded-full text-sm font-medium ${categoryFilter === 'text' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>Text Tools</Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTools.map((tool, i) => (
          <Link to={tool.path} key={i} className="block group">
            <Card className="h-full transition-all duration-200 hover:shadow-md hover:border-indigo-200 cursor-pointer">
              <CardHeader>
                <div className="mb-4 bg-white border border-slate-100 w-12 h-12 rounded-lg flex items-center justify-center text-indigo-500 shadow-sm">
                  {tool.icon}
                </div>
                <CardTitle className="mb-2">
                  {tool.name}
                </CardTitle>
                <CardDescription>{tool.desc}</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
