import { apiFetch, getApiUrl } from "../utils/api";
import React, { useState } from "react";
import { SEO } from "../components/SEO";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Loader2, Download, RefreshCw, FileText } from "lucide-react";
import { AdSlot } from "../components/AdSlot";

export function TextToPdfPage() {
  const [text, setText] = useState("");
  const [title, setTitle] = useState("");
  const [fontSize, setFontSize] = useState("12");
  const [pageSize, setPageSize] = useState("A4");
  const [orientation, setOrientation] = useState("portrait");
  const [margin, setMargin] = useState("50");
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{ downloadUrl: string; filename: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!text.trim()) {
      setError("Please enter some text to generate a PDF.");
      return;
    }

    setIsProcessing(true);
    setError(null);
    
    try {
      const data = await apiFetch<{ downloadUrl: string; filename: string }>(
        "/api/pdf/text-to-pdf",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            text,
            title,
            fontSize,
            pageSize,
            orientation,
            margin
          }),
        }
      );
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <SEO 
        title="Text to PDF" 
        description="Convert plain text to a well-formatted PDF document." 
      />
      
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Text to PDF Generator</h1>
        <p className="text-slate-600">Instantly convert plain text into a formatted PDF document.</p>
      </div>

      <AdSlot type="top" className="mb-8" />

      {!result && (
        <Card className="p-6">
          <div className="flex flex-col gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Document Title (Optional)</label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter title here..."
                className="w-full p-3 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Document Content</label>
              <textarea 
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste or type your plain text here..."
                rows={12}
                className="w-full p-4 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm resize-y"
              />
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Font Size</label>
                <input 
                  type="number" 
                  min="8"
                  max="72"
                  value={fontSize}
                  onChange={(e) => setFontSize(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Page Size</label>
                <select 
                  value={pageSize}
                  onChange={(e) => setPageSize(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                >
                  <option value="A4">A4</option>
                  <option value="LETTER">Letter</option>
                  <option value="LEGAL">Legal</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Orientation</label>
                <select 
                  value={orientation}
                  onChange={(e) => setOrientation(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-indigo-500 outline-none bg-white"
                >
                  <option value="portrait">Portrait</option>
                  <option value="landscape">Landscape</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Margins (pt)</label>
                <input 
                  type="number" 
                  min="0"
                  max="200"
                  value={margin}
                  onChange={(e) => setMargin(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-md outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-600 rounded-md text-sm font-medium">
                {error}
              </div>
            )}

            <Button 
              size="lg" 
              className="w-full" 
              onClick={handleGenerate}
              disabled={isProcessing || !text.trim()}
            >
              {isProcessing ? (
                <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Generating PDF...</>
              ) : (
                "Generate PDF Document"
              )}
            </Button>
          </div>
        </Card>
      )}

      {result && (
        <Card className="text-center p-10">
          <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <FileText className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-2xl font-bold mb-6">PDF Generated Successfully!</h3>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <a href={getApiUrl(result.downloadUrl)} download={result.filename}>
                <Download className="w-4 h-4 mr-2" /> Download PDF
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={() => setResult(null)}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Generate Another
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
