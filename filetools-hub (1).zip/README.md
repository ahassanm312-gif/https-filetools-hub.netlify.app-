# FileTools Hub

FileTools Hub is a professional, complete full-stack web application providing free online tools for manipulating PDFs, images, documents, and text.

## Features

- **Full-Stack Architecture**: React (Vite) frontend + Express.js backend.
- **Image Processing**: Uses `sharp` to instantly compress, resize, and convert images server-side.
- **PDF Manipulation**: Uses `pdf-lib` for merging/splitting, `pdfkit` for text-to-pdf, and **Ghostscript** for genuine PDF compression and rendering PDF pages to JPGs.
- **Client-Side Tools**: Includes lightning-fast client-side utilities like Word & Character counters.
- **SEO & Advertising Ready**: Components are in place for SEO metadata (`<Helmet>`) and Monetization (`<AdSlot>`).
- **Temporary Secure Storage**: Uploaded files are processed into `/uploads` and automatically cleaned up via a periodic backend task.
- **Privacy First**: No permanent storage of user data or uploaded files.

## Required Dependencies

### System Packages
To run the genuine PDF compression and PDF-to-JPG rendering pipelines, **Ghostscript** must be installed on your server environment.

- **Linux (Ubuntu/Debian)**: 
  ```bash
  sudo apt-get update
  sudo apt-get install ghostscript
  ```
- **Linux (CentOS/RHEL)**:
  ```bash
  sudo yum install ghostscript
  ```
- **Windows**:
  Download and install the latest Ghostscript executable from [ghostscript.com](https://www.ghostscript.com/). 
  *Important*: You must add the Ghostscript `bin` folder (e.g., `C:\Program Files\gs\gs10.02.0\bin`) to your Windows system `PATH` environment variable so the application can invoke `gs` directly.

### Node Modules
Core Node dependencies include:
- `sharp` (Image processing)
- `pdf-lib` (PDF structure manipulation)
- `pdfkit` (PDF generation)
- `adm-zip` (ZIP archive generation)
- `express` & `multer` (Backend API & File handling)

## Installation & Development

```bash
# 1. Install Node dependencies
npm install

# 2. Start the development server (runs frontend + backend on port 3000)
npm run dev
```

## Production Build & Deployment

### Decoupled Deployment (Netlify Frontend + Separate Backend)
The frontend of FileTools Hub is fully compatible with static hosting platforms like **Netlify** or Vercel. 
However, because this application requires system-level packages like **Ghostscript** for genuine PDF compression and Rasterization, the backend **cannot** be natively hosted as standard Netlify Functions.

To deploy on Netlify:
1. **Frontend (Netlify):** Connect your GitHub repository to Netlify. The included `netlify.toml` will automatically configure the build settings (`npm run build`) and SPA routing. 
2. **Backend (VPS/Render/Railway):** Deploy this entire repository to a server that supports standard Node.js and allows installing OS packages (Ghostscript). 
3. **Environment Variable:** In your Netlify dashboard, set `VITE_API_BASE_URL` to the URL of your deployed Node backend (e.g., `https://api.yourdomain.com`). The frontend will automatically route all conversion requests to that separated backend. CORS is already configured.

### Full-Stack Monolith Deployment (VPS / Docker)
You can deploy both the frontend and backend together on a single server (like a DigitalOcean Droplet, AWS EC2, or Cloud Run):

**Requirements:**
- Node.js v18+
- Ghostscript installed and accessible in the system path.
- Write access to the `/uploads` directory in the project root.
- Minimum 1GB RAM recommended for processing larger PDFs/Images.

```bash
# 1. Build both frontend and backend
npm run build

# 2. Start the production server
npm run start
```

## Environment Variables

Check `.env.example` to see the variables you can configure:

- `PORT` (default 3000)
- `MAX_FILE_SIZE` (default 100MB)
- `MAX_FILES` (default 20)
- `FILE_RETENTION_MINUTES` (default 60)
- `ADSENSE_CLIENT_ID`
- `ADSTERRA_PUBLISHER_ID`

## Expanding the Application

To add a new tool:
1. Add the specific endpoint in `server.ts` (e.g., `app.post("/api/tool-name")`).
2. Create the frontend React component under `src/pages/ToolNamePage.tsx`.
3. Add the route in `src/App.tsx`.
4. Add the tool to the catalog in `src/pages/AllToolsPage.tsx` and the popular tools array in `src/pages/HomePage.tsx`.
