import express from "express";
import path from "path";
import cors from "cors";
import helmet from "helmet";
import multer from "multer";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import sharp from "sharp";
import { PDFDocument } from "pdf-lib";
import { exec } from "child_process";
import AdmZip from "adm-zip";
import PDFKitDocument from "pdfkit";

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Setup temporary uploads directory early
const UPLOAD_DIR = path.join(process.cwd(), "uploads");
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// File cleanup helpers: immediately delete temporary upload files
function safeUnlink(filePath?: string | null) {
  if (filePath && typeof filePath === "string") {
    try {
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch {}
  }
}

function safeUnlinkFiles(files?: Express.Multer.File[] | null) {
  if (files && Array.isArray(files)) {
    files.forEach(f => safeUnlink(f.path));
  }
}

// Configure CORS for decoupled frontend deployment (e.g. Netlify)
const configuredCorsOrigins = (process.env.CORS_ORIGIN || "")
  .split(",")
  .map(o => o.trim().replace(/\/+$/, ""))
  .filter(Boolean);

app.use(cors({
  origin: (requestOrigin, callback) => {
    // Requests with no origin (e.g. same-origin, curl, server-to-server) are allowed
    if (!requestOrigin) return callback(null, true);

    // If wildcard origin configured or nothing configured in dev
    if (!process.env.CORS_ORIGIN || process.env.CORS_ORIGIN === "*") {
      return callback(null, true);
    }

    const normalized = requestOrigin.replace(/\/+$/, "");

    // Check configured production origins
    if (configuredCorsOrigins.includes(normalized)) {
      return callback(null, true);
    }

    // Always allow localhost and 127.0.0.1 for seamless local development
    if (
      normalized.startsWith("http://localhost:") ||
      normalized.startsWith("https://localhost:") ||
      normalized.startsWith("http://127.0.0.1:") ||
      normalized.startsWith("https://127.0.0.1:")
    ) {
      return callback(null, true);
    }

    return callback(new Error(`Origin ${requestOrigin} is not allowed by CORS policy`));
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"]
}));

// Security and utility middleware
app.use(helmet({
  contentSecurityPolicy: process.env.NODE_ENV === "production" ? undefined : false,
  crossOriginResourcePolicy: { policy: "cross-origin" },
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Robots.txt and Sitemap.xml direct endpoints with dynamic site URL replacement
app.get("/robots.txt", (req, res) => {
  const robotsPath = path.join(process.cwd(), "public", "robots.txt");
  const siteUrl = (process.env.VITE_SITE_URL || process.env.SITE_URL || "https://filetoolshub.com").replace(/\/+$/, "");
  let content = "User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: " + siteUrl + "/sitemap.xml\n";
  if (fs.existsSync(robotsPath)) {
    const raw = fs.readFileSync(robotsPath, "utf-8");
    content = raw.replace(/https:\/\/filetoolshub\.com/g, siteUrl);
  }
  res.type("text/plain").send(content);
});

app.get("/sitemap.xml", (req, res) => {
  const sitemapPath = path.join(process.cwd(), "public", "sitemap.xml");
  const siteUrl = (process.env.VITE_SITE_URL || process.env.SITE_URL || "https://filetoolshub.com").replace(/\/+$/, "");
  if (fs.existsSync(sitemapPath)) {
    const raw = fs.readFileSync(sitemapPath, "utf-8");
    const content = raw.replace(/https:\/\/filetoolshub\.com/g, siteUrl);
    res.type("application/xml").send(content);
  } else {
    res.status(404).send("Sitemap not found");
  }
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", uptime: process.uptime(), timestamp: Date.now() });
});

// Setup Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname.replace(/[^a-zA-Z0-9.-]/g, "_"));
  },
});
const upload = multer({
  storage,
  limits: { fileSize: Number(process.env.MAX_FILE_SIZE) || 104857600 }, // 100MB default
});

// Periodic cleanup of orphaned/expired files (defaults to 15 minutes)
const cleanupOldFiles = () => {
  const retentionMinutes = Number(process.env.FILE_RETENTION_MINUTES) || 15;
  const retentionMs = retentionMinutes * 60 * 1000;
  const now = Date.now();
  
  fs.readdir(UPLOAD_DIR, (err, files) => {
    if (err) return;
    files.forEach(file => {
      if (file === ".gitkeep") return;
      const filePath = path.join(UPLOAD_DIR, file);
      fs.stat(filePath, (err, stats) => {
        if (err) return;
        if (now - stats.mtimeMs > retentionMs) {
          safeUnlink(filePath);
        }
      });
    });
  });
};
setInterval(cleanupOldFiles, 5 * 60 * 1000); // Check every 5 minutes
cleanupOldFiles(); // Run on startup to clear any leftovers

// ==========================================
// API Endpoints
// ==========================================

// Image Compressor Tool
app.post("/api/image/compress", upload.single("file"), async (req, res) => {
  let outputPath: string | null = null;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const quality = parseInt(req.body.quality) || 80;
    const format = req.body.format || "jpeg"; // jpeg, png, webp
    outputPath = path.join(UPLOAD_DIR, `compressed_${req.file.filename}.${format}`);

    let sharpInstance = sharp(req.file.path);
    
    if (format === "jpeg" || format === "jpg") {
      sharpInstance = sharpInstance.jpeg({ quality });
    } else if (format === "png") {
      sharpInstance = sharpInstance.png({ quality });
    } else if (format === "webp") {
      sharpInstance = sharpInstance.webp({ quality });
    }

    await sharpInstance.toFile(outputPath);
    
    // Immediately unlink the temporary uploaded file
    safeUnlink(req.file.path);

    // Provide a URL to download the processed file
    const downloadUrl = `/api/download/${path.basename(outputPath)}`;
    const newStats = fs.statSync(outputPath);
    
    res.json({
      success: true,
      originalSize: req.file.size,
      newSize: newStats.size,
      downloadUrl,
      filename: `compressed_${req.file.originalname}`
    });
  } catch (err) {
    safeUnlink(req.file?.path);
    if (outputPath) safeUnlink(outputPath);
    console.error("Compression error:", err);
    res.status(500).json({ error: "Failed to compress image." });
  }
});

// Helper to validate and clean PDF buffer
function validateAndCleanPdf(filePath: string): { valid: boolean; error?: string; buffer?: Buffer; headerOffset?: number } {
  try {
    if (!fs.existsSync(filePath)) {
      return { valid: false, error: "Uploaded file was not found on the server." };
    }
    const buffer = fs.readFileSync(filePath);
    if (!buffer || buffer.length === 0) {
      return { valid: false, error: "The uploaded file is empty (0 bytes)." };
    }

    // Check if the file is an HTML page (such as error or auth/cookie check page) saved with .pdf
    const startStr = buffer.subarray(0, 2048).toString("utf8").toLowerCase();
    if (startStr.includes("<!doctype html") || startStr.includes("<html") || startStr.includes("<head") || startStr.includes("<body")) {
      return {
        valid: false,
        error: "The uploaded file is an HTML web page, not a valid PDF document. Please make sure you are uploading a genuine PDF file."
      };
    }

    // Look for %PDF- in the file
    const headerOffset = buffer.indexOf(Buffer.from("%PDF-"));
    if (headerOffset === -1) {
      return {
        valid: false,
        error: "The uploaded file does not contain a valid PDF header ('%PDF-'). Please ensure the file is an uncorrupted PDF."
      };
    }

    // If headerOffset > 0, trim leading garbage/BOM
    const cleanBuffer = headerOffset > 0 ? buffer.subarray(headerOffset) : buffer;
    return { valid: true, buffer: cleanBuffer, headerOffset };
  } catch (err: any) {
    return { valid: false, error: `Failed to read uploaded file: ${err.message}` };
  }
}

// PDF Merge Tool
app.post("/api/pdf/merge", upload.array("files", 20), async (req, res) => {
  let outputPath: string | null = null;
  const files = req.files as Express.Multer.File[];
  try {
    if (!files || files.length < 2) {
      safeUnlinkFiles(files);
      return res.status(400).json({ error: "At least 2 PDF files are required to merge." });
    }

    // Validate all uploaded files
    for (const file of files) {
      const validation = validateAndCleanPdf(file.path);
      if (!validation.valid) {
        safeUnlinkFiles(files);
        return res.status(400).json({ 
          error: `File "${file.originalname}" is invalid: ${validation.error}` 
        });
      }
    }

    const outputFilename = `merged_${Date.now()}.pdf`;
    outputPath = path.join(UPLOAD_DIR, outputFilename);

    let mergeSuccessful = false;
    let newPdfSize = 0;

    // Try pdf-lib first
    try {
      const mergedPdf = await PDFDocument.create();
      for (const file of files) {
        const validation = validateAndCleanPdf(file.path);
        const pdfDoc = await PDFDocument.load(validation.buffer!, { ignoreEncryption: true });
        const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
        copiedPages.forEach((page) => mergedPdf.addPage(page));
      }

      const mergedPdfBytes = await mergedPdf.save();
      fs.writeFileSync(outputPath, mergedPdfBytes);
      newPdfSize = mergedPdfBytes.length;
      mergeSuccessful = true;
    } catch (pdfLibErr) {
      console.warn("pdf-lib merge failed, falling back to Ghostscript:", pdfLibErr);

      // Ghostscript merge fallback
      await new Promise<void>((resolve, reject) => {
        const inputFilesStr = files.map(f => `"${f.path}"`).join(" ");
        const gsCmd = `gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${outputPath}" ${inputFilesStr}`;
        exec(gsCmd, (gsErr, stdout, stderr) => {
          if (gsErr) {
            return reject(new Error(stderr || gsErr.message));
          }
          resolve();
        });
      });

      if (fs.existsSync(outputPath)) {
        newPdfSize = fs.statSync(outputPath).size;
        mergeSuccessful = true;
      }
    }

    // Immediately clean up uploaded input files
    safeUnlinkFiles(files);

    if (!mergeSuccessful || !fs.existsSync(outputPath)) {
      if (outputPath) safeUnlink(outputPath);
      return res.status(500).json({ error: "Failed to merge PDFs." });
    }

    res.json({
      success: true,
      downloadUrl: `/api/download/${outputFilename}`,
      filename: "merged.pdf",
      newSize: newPdfSize
    });
  } catch (err: any) {
    safeUnlinkFiles(files);
    if (outputPath) safeUnlink(outputPath);
    console.error("PDF Merge error:", err);
    res.status(400).json({ error: err.message || "Failed to merge PDFs." });
  }
});

// Image Format Converter
app.post("/api/image/convert", upload.single("file"), async (req, res) => {
  let outputPath: string | null = null;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const format = req.body.format || "jpeg"; // target format
    outputPath = path.join(UPLOAD_DIR, `converted_${req.file.filename}.${format}`);

    let sharpInstance = sharp(req.file.path);
    
    if (format === "jpeg" || format === "jpg") {
      sharpInstance = sharpInstance.jpeg();
    } else if (format === "png") {
      sharpInstance = sharpInstance.png();
    } else if (format === "webp") {
      sharpInstance = sharpInstance.webp();
    }

    await sharpInstance.toFile(outputPath);
    
    // Immediately unlink uploaded input file
    safeUnlink(req.file.path);

    res.json({
      success: true,
      downloadUrl: `/api/download/${path.basename(outputPath)}`,
      filename: `converted_${path.parse(req.file.originalname).name}.${format}`
    });
  } catch (err) {
    safeUnlink(req.file?.path);
    if (outputPath) safeUnlink(outputPath);
    console.error("Conversion error:", err);
    res.status(500).json({ error: "Failed to convert image." });
  }
});

// Image Resizer
app.post("/api/image/resize", upload.single("file"), async (req, res) => {
  let outputPath: string | null = null;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const width = parseInt(req.body.width) || undefined;
    const height = parseInt(req.body.height) || undefined;
    const format = req.body.format || "jpeg";

    outputPath = path.join(UPLOAD_DIR, `resized_${req.file.filename}.${format}`);

    let sharpInstance = sharp(req.file.path);
    if (width || height) {
      sharpInstance = sharpInstance.resize(width, height, { fit: 'inside', withoutEnlargement: true });
    }

    if (format === "jpeg" || format === "jpg") sharpInstance = sharpInstance.jpeg();
    else if (format === "png") sharpInstance = sharpInstance.png();
    else if (format === "webp") sharpInstance = sharpInstance.webp();

    await sharpInstance.toFile(outputPath);
    
    // Immediately unlink uploaded input file
    safeUnlink(req.file.path);

    const newStats = fs.statSync(outputPath);
    res.json({
      success: true,
      originalSize: req.file.size,
      newSize: newStats.size,
      downloadUrl: `/api/download/${path.basename(outputPath)}`,
      filename: `resized_${path.parse(req.file.originalname).name}.${format}`
    });
  } catch (err) {
    safeUnlink(req.file?.path);
    if (outputPath) safeUnlink(outputPath);
    console.error("Resize error:", err);
    res.status(500).json({ error: "Failed to resize image." });
  }
});

// Image to PDF
app.post("/api/pdf/image-to-pdf", upload.array("files", 20), async (req, res) => {
  let outputPath: string | null = null;
  const files = req.files as Express.Multer.File[];
  try {
    if (!files || files.length === 0) return res.status(400).json({ error: "No files uploaded." });

    const pdfDoc = await PDFDocument.create();

    for (const file of files) {
      // Normalize any image format (JPG, PNG, WEBP, TIFF, etc.) to PNG buffer for robust embedding
      const pngBuffer = await sharp(file.path).png().toBuffer();
      const image = await pdfDoc.embedPng(pngBuffer);

      const page = pdfDoc.addPage([image.width, image.height]);
      page.drawImage(image, {
        x: 0,
        y: 0,
        width: image.width,
        height: image.height,
      });
    }

    const pdfBytes = await pdfDoc.save();
    const outputFilename = `images_to_pdf_${Date.now()}.pdf`;
    outputPath = path.join(UPLOAD_DIR, outputFilename);
    
    fs.writeFileSync(outputPath, pdfBytes);
    
    // Immediately unlink uploaded image files
    safeUnlinkFiles(files);

    res.json({
      success: true,
      downloadUrl: `/api/download/${outputFilename}`,
      filename: "converted.pdf",
      newSize: pdfBytes.length
    });
  } catch (err: any) {
    safeUnlinkFiles(files);
    if (outputPath) safeUnlink(outputPath);
    console.error("Image to PDF error:", err);
    res.status(500).json({ error: "Failed to convert images to PDF: " + (err?.message || "Unknown error") });
  }
});

// Split PDF
app.post("/api/pdf/split", upload.single("file"), async (req, res) => {
  let outputPath: string | null = null;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    // Validate uploaded PDF
    const validation = validateAndCleanPdf(req.file.path);
    if (!validation.valid || !validation.buffer) {
      safeUnlink(req.file.path);
      return res.status(400).json({ error: validation.error || "The uploaded file is not a valid PDF document." });
    }

    const startPage = parseInt(req.body.startPage) || 1;
    let endPage = parseInt(req.body.endPage) || undefined;

    const outputFilename = `split_${Date.now()}.pdf`;
    outputPath = path.join(UPLOAD_DIR, outputFilename);

    let splitSuccessful = false;
    let newPdfSize = 0;

    // Try pdf-lib first
    try {
      const originalPdf = await PDFDocument.load(validation.buffer, { ignoreEncryption: true });
      const totalPages = originalPdf.getPageCount();
      if (!endPage || isNaN(endPage)) {
        endPage = totalPages;
      }

      if (startPage < 1 || startPage > endPage) {
        safeUnlink(req.file.path);
        return res.status(400).json({ error: "Invalid page range. Start page must be at least 1 and less than or equal to end page." });
      }

      if (startPage > totalPages) {
        safeUnlink(req.file.path);
        return res.status(400).json({ 
          error: `Start page (${startPage}) exceeds the total number of pages in the PDF (${totalPages}).` 
        });
      }

      const actualStart = Math.max(1, startPage) - 1;
      const actualEnd = Math.min(totalPages, endPage) - 1;

      const newPdf = await PDFDocument.create();
      const pagesToCopy = Array.from({ length: actualEnd - actualStart + 1 }, (_, i) => actualStart + i);
      const copiedPages = await newPdf.copyPages(originalPdf, pagesToCopy);
      copiedPages.forEach((page) => newPdf.addPage(page));

      const newPdfBytes = await newPdf.save();
      fs.writeFileSync(outputPath, newPdfBytes);
      newPdfSize = newPdfBytes.length;
      splitSuccessful = true;
    } catch (pdfLibErr) {
      console.warn("pdf-lib split failed, falling back to Ghostscript:", pdfLibErr);

      // Ghostscript fallback
      await new Promise<void>((resolve, reject) => {
        const gsCmd = `gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dNOPAUSE -dQUIET -dBATCH -dFirstPage=${startPage} -dLastPage=${endPage} -sOutputFile="${outputPath}" "${req.file!.path}"`;
        exec(gsCmd, (gsErr, stdout, stderr) => {
          if (gsErr) {
            return reject(new Error(stderr || gsErr.message));
          }
          resolve();
        });
      });

      if (fs.existsSync(outputPath)) {
        newPdfSize = fs.statSync(outputPath).size;
        splitSuccessful = true;
      }
    }

    // Immediately unlink the uploaded input PDF
    safeUnlink(req.file.path);

    if (!splitSuccessful || !fs.existsSync(outputPath)) {
      if (outputPath) safeUnlink(outputPath);
      return res.status(500).json({ error: "Failed to split PDF. The document structure may be corrupted or protected." });
    }

    res.json({
      success: true,
      downloadUrl: `/api/download/${outputFilename}`,
      filename: `split_${req.file.originalname}`,
      newSize: newPdfSize
    });
  } catch (err: any) {
    safeUnlink(req.file?.path);
    if (outputPath) safeUnlink(outputPath);
    console.error("Split PDF error:", err);
    res.status(400).json({ error: err.message || "Failed to split PDF." });
  }
});

// Compress PDF
app.post("/api/pdf/compress", upload.single("file"), (req, res) => {
  let outputPath: string | null = null;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    // Validate uploaded PDF
    const validation = validateAndCleanPdf(req.file.path);
    if (!validation.valid) {
      safeUnlink(req.file.path);
      return res.status(400).json({ error: validation.error || "The uploaded file is not a valid PDF document." });
    }

    const level = req.body.level || "medium"; // low, medium, high
    
    let pdfSettings = "/ebook"; // medium
    if (level === "low") pdfSettings = "/printer"; // lower compression, better quality
    if (level === "high") pdfSettings = "/screen"; // higher compression, lower quality

    const outputFilename = `compressed_${Date.now()}.pdf`;
    outputPath = path.join(UPLOAD_DIR, outputFilename);

    const gsCommand = `gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS=${pdfSettings} -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${outputPath}" "${req.file.path}"`;

    exec(gsCommand, (error, stdout, stderr) => {
      // Immediately clean up uploaded input file
      safeUnlink(req.file?.path);

      if (error) {
        if (outputPath) safeUnlink(outputPath);
        console.error("Ghostscript compress error:", error, stderr);
        return res.status(500).json({ error: "Failed to compress PDF natively. " + (stderr || error.message) });
      }
      
      const newStats = fs.statSync(outputPath);
      res.json({
        success: true,
        originalSize: req.file!.size,
        newSize: newStats.size,
        downloadUrl: `/api/download/${outputFilename}`,
        filename: `compressed_${req.file!.originalname}`
      });
    });
  } catch (err: any) {
    safeUnlink(req.file?.path);
    if (outputPath) safeUnlink(outputPath);
    console.error("PDF compress error:", err);
    res.status(400).json({ error: err.message || "Failed to compress PDF." });
  }
});

// PDF to JPG (supports both /api/pdf/to-jpg and /api/pdf-to-jpg)
app.post(["/api/pdf/to-jpg", "/api/pdf-to-jpg"], upload.single("file"), (req, res) => {
  const outputPrefix = `pdf2jpg_${Date.now()}`;
  try {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    // Validate uploaded PDF
    const validation = validateAndCleanPdf(req.file.path);
    if (!validation.valid) {
      safeUnlink(req.file.path);
      return res.status(400).json({ error: validation.error || "The uploaded file is not a valid PDF document." });
    }
    
    const quality = parseInt(req.body.quality) || 80;
    const resolution = parseInt(req.body.resolution) || 150;
    const startPage = parseInt(req.body.startPage) || 1;
    let endPage = parseInt(req.body.endPage) || undefined;
    
    const outputPattern = path.join(UPLOAD_DIR, `${outputPrefix}-%03d.jpg`);
    
    let pageRange = `-dFirstPage=${startPage}`;
    if (endPage && endPage >= startPage) {
      pageRange += ` -dLastPage=${endPage}`;
    }

    const gsCommand = `gs -sDEVICE=jpeg -r${resolution} -dJPEGQ=${quality} ${pageRange} -dNOPAUSE -dQUIET -dBATCH -sOutputFile="${outputPattern}" "${req.file.path}"`;

    exec(gsCommand, (error, stdout, stderr) => {
      // Immediately clean up uploaded input PDF
      safeUnlink(req.file?.path);

      if (error) {
        // Clean up partial files
        try {
          const partialFiles = fs.readdirSync(UPLOAD_DIR).filter(f => f.startsWith(outputPrefix));
          partialFiles.forEach(f => safeUnlink(path.join(UPLOAD_DIR, f)));
        } catch {}

        console.error("Ghostscript PDF to JPG error:", error, stderr);
        return res.status(500).json({ error: "Failed to convert PDF to JPG. Ghostscript error: " + (stderr || error.message) });
      }
      
      // Find all generated images
      const files = fs.readdirSync(UPLOAD_DIR).filter(f => f.startsWith(outputPrefix) && f.endsWith('.jpg'));
      files.sort(); // ensure chronological order
      
      const images = files.map(f => ({
        filename: f,
        downloadUrl: `/api/download/${f}`
      }));
      
      if (images.length === 0) {
        return res.status(500).json({ error: "No images were generated. Please ensure the PDF is not empty or password-protected." });
      }

      // Create a zip file containing all images
      const zip = new AdmZip();
      files.forEach(f => {
        zip.addLocalFile(path.join(UPLOAD_DIR, f));
      });
      const zipFilename = `${outputPrefix}_all.zip`;
      zip.writeZip(path.join(UPLOAD_DIR, zipFilename));

      res.json({
        success: true,
        images,
        zipUrl: `/api/download/${zipFilename}`,
        zipFilename: `images_${req.file!.originalname.replace(/\.pdf$/i, '')}.zip`
      });
    });
  } catch (err: any) {
    safeUnlink(req.file?.path);
    try {
      const partialFiles = fs.readdirSync(UPLOAD_DIR).filter(f => f.startsWith(outputPrefix));
      partialFiles.forEach(f => safeUnlink(path.join(UPLOAD_DIR, f)));
    } catch {}

    console.error("PDF to JPG error:", err);
    res.status(500).json({ error: err?.message || "Failed to convert PDF." });
  }
});

// Informative handler for GET requests to PDF-to-JPG
app.get(["/api/pdf/to-jpg", "/api/pdf-to-jpg"], (req, res) => {
  res.status(405).json({
    error: "Method Not Allowed. Use POST multipart/form-data with a PDF file.",
    endpoint: req.path,
    success: false
  });
});

// Text to PDF
app.post("/api/pdf/text-to-pdf", (req, res) => {
  let outputPath: string | null = null;
  try {
    const { text, title, fontSize, pageSize, orientation, margin } = req.body;
    if (!text) return res.status(400).json({ error: "No text provided" });

    const docFontSize = parseInt(fontSize) || 12;
    const docMargin = parseInt(margin) || 50;
    const size = pageSize || "A4"; // A4, LETTER, etc.
    const layout = orientation || "portrait"; // portrait, landscape

    const doc = new PDFKitDocument({
      size: size as any,
      layout: layout as any,
      margins: { top: docMargin, bottom: docMargin, left: docMargin, right: docMargin }
    });

    const outputFilename = `text_${Date.now()}.pdf`;
    outputPath = path.join(UPLOAD_DIR, outputFilename);
    const writeStream = fs.createWriteStream(outputPath);
    
    doc.pipe(writeStream);

    // Metadata
    if (title) {
      doc.info.Title = title;
      doc.fontSize(docFontSize + 6).text(title, { align: 'center' });
      doc.moveDown();
    }

    doc.fontSize(docFontSize).text(text, {
      align: 'left',
    });

    doc.end();

    writeStream.on('finish', () => {
      res.json({
        success: true,
        downloadUrl: `/api/download/${outputFilename}`,
        filename: `${title ? title.replace(/[^a-zA-Z0-9]/g, "_") : "document"}.pdf`
      });
    });

    writeStream.on('error', (err) => {
      if (outputPath) safeUnlink(outputPath);
      console.error("Stream error:", err);
      res.status(500).json({ error: "Failed to write PDF file." });
    });

  } catch (err) {
    if (outputPath) safeUnlink(outputPath);
    console.error("Text to PDF error:", err);
    res.status(500).json({ error: "Failed to generate PDF." });
  }
});

// Download Endpoint
app.get(["/api/download", "/api/download/*", "/api/download/:filename"], (req, res) => {
  const rawUrl = req.originalUrl || req.url;
  if (rawUrl.includes("..") || rawUrl.includes("%2e") || rawUrl.includes("%2E")) {
    return res.status(400).json({ error: "Invalid filename: path traversal blocked", success: false });
  }

  const filename = path.basename(req.path);
  if (!filename || filename === "download" || filename.includes("..") || filename.includes("/")) {
    return res.status(400).json({ error: "Invalid filename", success: false });
  }
  
  const filePath = path.join(UPLOAD_DIR, filename);
  if (fs.existsSync(filePath)) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
    res.download(filePath);
  } else {
    res.status(404).json({ error: "File not found or expired", success: false });
  }
});

// Catch-all for undefined /api/* routes so they NEVER return HTML/SPA fallback
app.all("/api/*", (req, res) => {
  res.status(404).json({
    error: `API route not found: ${req.method} ${req.originalUrl}`,
    success: false
  });
});

// Global error handler for /api routes
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (req.path.startsWith("/api")) {
    console.error("API error:", err);
    return res.status(err.status || 500).json({
      error: err.message || "Internal server error",
      success: false
    });
  }
  next(err);
});

// Setup Vite Middleware for frontend
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
